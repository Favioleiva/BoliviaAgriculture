"""Test documented special-value equality against the unresolved coverage residual."""
from specification import *

def run():
 fields=json.loads((E/'Plans/coverage_probe.json').read_text(encoding='utf-8'))['fields']
 defs=[];cols=[];counts=[]
 for f in fields:
  for special in ['MISSING','NOTAPPLICABLE','DEFAULT']:
   column='V'+str(len(cols)+1)
   defs.append(f'DEFINE MUNIC.{column} AS COUNT {V[f]["entity"]} FILTER {f} = {special} TYPE INTEGER')
   cols.append('MUNIC.'+column);counts.append(dict(field=f,special=special,column=column))
 name='coverage_special_equality';output=E/'Results'/(name+'.csv')
 defs.append('TABLE CHECKS AS AREALIST OF MUNIC, '+', '.join(cols)+f'\n OUTPUTFILE CSV "{output}" UTF8')
 p=program(name,'\n'.join(defs))
 save(E/'Plans'/(name+'.json'),dict(name=name,program_sha256=sha(p),timeout_seconds=1800,counts=counts,outputs=[dict(path=str(output),rows=339,columns=len(cols)+1)]))
 print(name)

if __name__=='__main__':run()
