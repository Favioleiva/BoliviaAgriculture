from specification import *
from bs4 import BeautifulSoup
import re

def parse(p,f,prefix=''):
 soup=BeautifulSoup(p.read_text(encoding='utf-8'),'html.parser');rows=[];total=None
 for tr in soup.select('tr'):
  cells=[c.get_text(' ',strip=True) for c in tr.find_all('td',recursive=False)]
  if len(cells)<5:continue
  label,n,pct,cum=cells[1:5]
  if not (pct.endswith('%') or pct=='-'):continue
  clean=re.sub(r'\s','',n)
  if not (clean.isdigit() or clean=='-'):continue
  count=0 if clean=='-' else int(clean)
  if label=='Total':total=count;continue
  special='missing' if label.lower() in ['missing','missing value','missing values'] else 'not_applicable' if 'not applicable' in label.lower() else ''
  m=re.match(r'^([^ .]+)\.\s',label)
  code=m[1] if m else label
  if prefix:
   assert code.startswith(prefix),(f,repr(code))
   code=code[len(prefix):]
  if V[f]['type_effective']!='STRING' and not special:code=re.sub(r'\s','',code)
  cat=next((c for c in C[f] if c['code']==code),None)
  if count:rows.append(dict(code=code,label=cat['label'] if cat else (code if V[f]['type_effective']=='STRING' else 'Código '+code+' (sin etiqueta)' ),count=count,special=special,declared=bool(cat),nonresponse=bool(special or code=='' or (cat and str(cat['label_suggests_nonresponse']).lower()=='true'))))
 assert total is not None,(p,'no total')
 assert sum(r['count'] for r in rows)==total,(f,total,sum(r['count'] for r in rows))
 assert len(rows)==len({(r['code'],r['special']) for r in rows}),f
 return dict(field=f,total_records=total,categories=rows,source=p.relative_to(O).as_posix(),source_sha256=sha(p))

def run():
 result={}
 for name in json.loads((E/'discovery_queue.json').read_text(encoding='utf-8')):
  receipt=json.loads((E/'Results'/f'{name}_run.json').read_text(encoding='utf-8'));assert receipt['export_complete_stable'],name
  plan=json.loads((E/'Plans'/f'{name}.json').read_text(encoding='utf-8'))
  for f,p in zip(plan['fields'],plan['extra_files']):result[f]=parse(Path(p),f)
 save(E/'observed_domains.json',result)
 print('Parsed',len(result),'fields;',sum(len(r['categories']) for r in result.values()),'observed categories')
if __name__=='__main__':run()
