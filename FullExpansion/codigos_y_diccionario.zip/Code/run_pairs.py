from common import *
from run_program import run
from concurrent.futures import ThreadPoolExecutor,as_completed
import traceback
def work(name):
 receipt=run(name);cfg=json.loads((E/'Plans'/(name+'.json')).read_text(encoding='utf-8'))
 for src,out in zip(cfg['paired_sources'],receipt['outputs']):
  child=dict(receipt,name=src,outputs=[out],executed_program=name+'.spc',parent_receipt=name+'_run.json',method='Independent MUNIC and DEPTO DEFINE aggregates; shared UPA predicate definitions; two native AREALIST tables in one process')
  save(E/'Results'/(src+'_run.json'),child);save(E/('active_'+src+'.json'),dict(active=False,last_status=child['status'],parent_job=name))
 return receipt
def main():
 queue=json.loads((E/'paired_queue.json').read_text(encoding='utf-8'));results=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(work,name):name for name in queue}
  for future in as_completed(jobs):
   name=jobs[future]
   try:r=future.result();results.append(dict(name=name,complete=r['export_complete_stable']))
   except Exception as e:results.append(dict(name=name,complete=False,error=str(e)));traceback.print_exc()
   save(E/'paired_progress.json',dict(created=now(),completed=results,total=len(queue)))
 print('PAIRED_QUEUE_COMPLETE',len(results),sum(r['complete'] for r in results),flush=True)
 if not all(r['complete'] for r in results):raise RuntimeError('Some native outputs need review; never overwrite them')
if __name__=='__main__':main()
