"""Exclude unclassified overlapping goat rows after exact aggregate verification."""
from specification import *
from decimal import Decimal
import shutil

def run():
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'))
 prior={r['codmun']:r for r in read(O/'Deliverables/Agro2013/animal_population_native_2013.csv')}
 cache={}
 def amount(r,k):
  name=r['execution_result']
  if name not in cache:cache[name]={x['REDCODE']:x for x in read(E/'Results'/name,';')}
  return Decimal(cache[name][k][r['redatam_column']])
 audit=[]
 for f in ['CAPRINO.S6_P60B','CAPRINO.S6_P60C','CAPRINO.S6_P60D']:
  total=next(r for r in recipes if r['source_variable']==f and r['context']=='species_total' and r['operation']=='sum')
  ages=[r for r in recipes if r['source_variable']==f and r['context']!='species_total' and r['operation']=='sum' and r['context_code'] in ['2','3','4']]
  assert len(ages)==3
  national=Decimal(0)
  for k in prior:
   s=sum(amount(r,k) for r in ages);national+=s
   assert amount(total,k)==2*s,(f,k,'All rows must be exactly twice labelled-age sum')
   if f.endswith('B'):assert s==Decimal(prior[k]['caprino']),(f,k,'Prior native total differs')
  audit.append(dict(field=f,municipalities=339,all_rows_equal_twice_labelled_age_sum=True,labelled_age_national=str(national),prior_total_comparison='PASS' if f.endswith('B') else 'not applicable'))
 save(E/'goat_total_overlap_validation.json',dict(created=now(),status='PASS',checks=audit,decision='Only labelled age groups 2/3/4 enter species totals. Unclassified rows have quantities exactly equal to these components in all 339 municipalities. Their raw key is not inferred; original all-row attempt remains in evidence.'))
 old='extra_totals_000_v2';new='extra_totals_000_v3'
 part=[dict(r) for r in recipes if r['execution_program']==old+'_m.spc'];assert len(part)==160
 assert not (E/'Plans'/(new+'_m.json')).exists(),'Already created'
 changed=[]
 for r in part:
  if r['entity']=='CAPRINO':
   base='(CAPRINO.S6_P60A = 2 OR CAPRINO.S6_P60A = 3 OR CAPRINO.S6_P60A = 4)'
   r['filter']=base;r['context_code']='LABELLED_AGE_GROUPS_2_3_4';r['context_label']='Caprinos · grupos de edad 2/3/4; sin filas superpuestas'
   oldcond=r['effective_filter'];cond=base+(' AND ('+oldcond+')' if oldcond else '')
   r['effective_filter']=cond;r['semantic_limit']='Se excluyen filas de edad no clasificadas cuya suma duplica exactamente los grupos etiquetados; no se atribuye un código ni etiqueta a esas filas.'
   kind=r['operation'];column=r['redatam_column'];i=column[1:]
   if kind.startswith('holdings'):
    r['prerequisites']=f'DEFINE UPA.R{i} AS COUNT CAPRINO FILTER {cond} TYPE INTEGER';expr=f'COUNT UPA FILTER UPA.R{i} > 0'
   elif kind=='sum':expr='SUM '+r['source_variable']+' FILTER '+cond
   else:expr='COUNT CAPRINO FILTER '+cond
   r['redatam_code']=f'DEFINE MUNIC.{column} AS {expr} TYPE '+('REAL DECIMALS 6' if kind=='sum' else 'INTEGER')
   r['reproduction_program']=r['indicator_id']+'_v3.spc';out=E/'RecipeRuns'/(r['indicator_id']+'_v3.csv')
   write(D/'Recipes'/r['reproduction_program'],f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+r['prerequisites']+'\n'+r['redatam_code']+f'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.{column}\n OUTPUTFILE CSV "{out}" UTF8\n')
   r['reproduction_sha256']=sha(D/'Recipes'/r['reproduction_program']);changed.append(r['indicator_id'])
  r['execution_program']=new+'_m.spc';r['execution_result']=new+'_m.csv'
 defs=[]
 for r in part:
  if r['prerequisites']:defs.append(r['prerequisites'])
  defs.append(r['redatam_code'])
 for suffix,level,rows in [('m','MUNIC',339),('d','DEPTO',9)]:
  name=new+'_'+suffix;out=E/'Results'/(name+'.csv')
  body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(level+'.'+r['redatam_column'] for r in part)+f'\n OUTPUTFILE CSV "{out}" UTF8'
  p=program(name,body);shutil.copy2(p,D/'Programs'/p.name)
  save(E/'Plans'/(name+'.json'),dict(name=name,group='mixed_supplements',level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(out),rows=rows,columns=len(part)+1)],recipes=part))
 for r in part:r['program_sha256']=sha(E/'Programs'/(new+'_m.spc'))
 replacements={r['indicator_id']:r for r in part}
 save(E/'History/recipes_before_goat_correction.json',recipes)
 save(E/'recipes.json',[replacements.get(r['indicator_id'],r) for r in recipes])
 queue=json.loads((E/'queue.json').read_text(encoding='utf-8'));save(E/'queue.json',[name.replace(old,new) if name.startswith(old+'_') else name for name in queue])
 save(E/'goat_correction_queue.json',[new+'_m',new+'_d'])
 save(E/'goat_correction.json',dict(created=now(),status='GENERATED_PENDING_EXECUTION',changed_indicators=changed,superseded_batch=old,canonical_batch=new,original_attempt_preserved=True))
 print('Verified goat overlapping rows; corrected',len(changed),'recipes; pig correction preserved.')

if __name__=='__main__':run()
