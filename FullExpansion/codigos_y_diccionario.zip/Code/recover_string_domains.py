"""Recover exact string codes from prefixed native frequencies; no inferred zero-padding."""
from parse_discovery import *
import shutil
def run():
 target=E/'observed_domains.json';old=json.loads(target.read_text(encoding='utf-8'));mapping=[]
 backup=E/'History/observed_domains_before_prefix.json'
 assert not backup.exists(),'Already recovered'
 result=dict(old)
 for name in json.loads((E/'rawstrings_queue.json').read_text(encoding='utf-8')):
  receipt=json.loads((E/'Results'/f'{name}_run.json').read_text(encoding='utf-8'));assert receipt['export_complete_stable']
  plan=json.loads((E/'Plans'/f'{name}.json').read_text(encoding='utf-8'))
  for f,path in zip(plan['fields'],plan['extra_files']):
   actual=parse(Path(path),f,'X');assert actual['total_records']==old[f]['total_records']
   remaining=list(actual['categories']);ordered=[]
   for before in old[f]['categories']:
    candidates=[c for c in remaining if c['code']==before['code'] and c['count']==before['count']]
    if not candidates and before['code'].isdigit():
     candidates=[c for c in remaining if c['code'].isdigit() and int(c['code'])==int(before['code']) and c['count']==before['count']]
    assert len(candidates)==1,(f,before,candidates)
    c=candidates[0];remaining.remove(c);ordered.append(c)
    if before['code']!=c['code']:mapping.append(dict(field=f,displayed_code=before['code'],exact_code=c['code'],national_count=c['count'],evidence=actual['source']))
   assert not remaining,(f,remaining)
   actual['categories']=ordered;actual['recovery']='Prefix X + TRIM(source) prevents HTML renderer dropping leading zeroes; original category order retained after bijective count/code matching.';result[f]=actual
 shutil.copy2(target,backup);save(target,result);save(E/'string_code_recovery.json',dict(created=now(),status='PASS',mapping=mapping,method='Observed prefixed native aggregate codes, not inferred padding; one-to-one matches and exact national counts verified',initial_diagnosis='Spaces explain empty string comparison, but not the short numeric codes; native HTML renders unlabelled numeric strings without leading zeroes. TRIM alone failed.'))
 print('Recovered',len(mapping),'display-truncated codes in 28 string fields')
if __name__=='__main__':run()
