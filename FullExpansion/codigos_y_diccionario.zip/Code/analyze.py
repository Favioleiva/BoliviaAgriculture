"""Validate every native output, preserve discrepancies, export municipal/module matrices."""
from specification import *
from decimal import Decimal
import shutil,sys

def run():
 queue=json.loads((E/'queue.json').read_text(encoding='utf-8'));recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'))
 schema_digest=sha(BASE/'schema.json');dictionary_digest=sha(W/'CNA2013.dicx');normalized=0
 for r in recipes:
  if r.get('source_dictionary_sha256')==schema_digest:
   normalized+=1
  else:assert r.get('source_dictionary_sha256',dictionary_digest)==dictionary_digest
  assert r.get('source_schema_sha256',schema_digest)==schema_digest
  r['source_schema_sha256']=schema_digest;r['source_dictionary_sha256']=dictionary_digest
 save(E/'source_provenance_normalization.json',dict(created=now(),source_schema_sha256=schema_digest,source_dictionary_sha256=dictionary_digest,legacy_metadata_keys_corrected=normalized,explanation='Early generated metadata labelled the extracted-schema hash as dictionary hash. Final metadata explicitly separates the schema JSON from CNA2013.dicx. Native program and result hashes are unchanged.'))
 byid={r['indicator_id']:r for r in recipes};values={};rawsum={};failures=[];checks=0;keyorder=None
 previous=read(O/'Deliverables/Agro2013/animal_population_native_2013.csv');geo={r['codmun']:r for r in previous};expected_keys=set(geo)
 domains=json.loads((E/'observed_domains.json').read_text(encoding='utf-8'))
 for name in queue:
  receipt=json.loads((E/'Results'/f'{name}_run.json').read_text(encoding='utf-8'));assert receipt['export_complete_stable'],name
  cfg=json.loads((E/'Plans'/f'{name}.json').read_text(encoding='utf-8'));result=E/'Results'/f'{name}.csv'
  assert sha(result)==receipt['outputs'][0]['sha256'];assert sha(E/'Programs'/receipt.get('executed_program',f'{name}.spc'))==receipt['program_sha256']
  shutil.copy2(result,D/'RawResults'/result.name)
  if not name.endswith('_m'):continue
  rows=read(result,';');m={r['REDCODE']:r for r in rows};drows=read(E/'Results'/(name[:-1]+'d.csv'),';');departments={r['REDCODE']:r for r in drows}
  assert len(m)==len(rows)==339 and set(m)==expected_keys,name
  assert len(departments)==len(drows)==9 and set(departments)=={k[:2] for k in m},name
  keyorder=sorted(m)
  for recipe in cfg['recipes']:
   iid=recipe['indicator_id'];col=recipe['redatam_column'];r=byid[iid]
   vals=[Decimal(m[k][col]) for k in keyorder];assert all(v.is_finite() and v>=0 for v in vals),iid
   if r['integer_expected']:assert all(v==int(v) for v in vals),iid
   for dep in sorted(departments):
    inds=[i for i,k in enumerate(keyorder) if k[:2]==dep];actual=sum((vals[i] for i in inds),Decimal(0));control=Decimal(departments[dep][col]);difference=actual-control
    tol=Decimal(0) if r['integer_expected'] else Decimal('0.0000005')*(len(inds)+1)
    checks+=1
    if abs(difference)>tol:failures.append(dict(indicator_id=iid,test='municipal_to_department',department=dep,actual=str(actual),expected=str(control),difference=str(difference),tolerance=str(tol),kind='integer' if r['integer_expected'] else 'real'))
   total=sum(vals,Decimal(0));r['raw_national_total']=str(total)
   if r['expected_national'] is not None:
    checks+=1
    if total!=r['expected_national']:failures.append(dict(indicator_id=iid,test='national_frequency',department='',actual=str(total),expected=str(r['expected_national']),difference=str(total-r['expected_national']),tolerance='0',kind='integer'))
   values[iid]=[int(v) if r['integer_expected'] else float(v) for v in vals]
   if r['operation']=='sum':rawsum[iid]=[format(v,'f') for v in vals]
 # Within-group checks cover missingness and one-to-many risks.
 contexts=defaultdict(dict);entity_counts={}
 for r in recipes:
  contexts[(r['source_variable'],r['context'])][r['operation']]=r
  if r['operation']=='entity_records':entity_counts[r['entity']]=values[r['indicator_id']]
 baseline=[int(geo[k]['nroupa']) for k in keyorder]
 assert entity_counts['UPA']==baseline
 # Validate the explicit unclassified bucket against the original municipal deficits.
 # This accounts for coverage; it does not establish a substantive meaning for the residual.
 original=json.loads((E/'History/validation_before_coverage_repair.json').read_text(encoding='utf-8'))
 deficits={(r['indicator_id'],r['department']):int(r['expected'])-int(r['actual']) for r in original['failures'] if r['test']=='frequency_partition'}
 residual_checks=0
 for r in recipes:
  if not r.get('coverage_residual') or r['context']!='unclassified_native' or r['operation']!='records':continue
  for i,k in enumerate(keyorder):
   assert values[r['indicator_id']][i]==deficits.get((r['source_variable'],k),0),(r['indicator_id'],k,'Original deficit mismatch')
   residual_checks+=1
 resolution=json.loads((E/'coverage_resolution.json').read_text(encoding='utf-8'))
 resolution.update(status='COUNTS_RECONCILED_SEMANTICS_UNRESOLVED',validated=now(),municipal_deficit_checks=residual_checks)
 save(E/'coverage_resolution.json',resolution);checks+=residual_checks
 for (f,ctx),ops in contexts.items():
  if 'records' not in ops:continue
  n=values[ops['records']['indicator_id']]
  for kind in ['holdings','holdings_valid','holdings_positive']:
   if kind not in ops:continue
   a=values[ops[kind]['indicator_id']]
   for i,x in enumerate(a):
    checks+=1
    if not 0<=x<=min(n[i],baseline[i]):failures.append(dict(indicator_id=ops[kind]['indicator_id'],test='upa_bounds',department=keyorder[i],actual=str(x),expected=str(min(n[i],baseline[i])),difference='',tolerance='0',kind='integer'))
  if 'sum' in ops:
   vv=values[ops['valid']['indicator_id']];mm=values[ops['missing']['indicator_id']];na=values[ops['not_applicable']['indicator_id']];zz=values[ops['zero']['indicator_id']];ss=values[ops['sum']['indicator_id']]
   statuses=[];outside=[]
   for i in range(339):
    checks+=1;out=n[i]-vv[i]-mm[i]-na[i];outside.append(out)
    if out<0 or zz[i]>vv[i]:failures.append(dict(indicator_id=ops['sum']['indicator_id'],test='validity_partition',department=keyorder[i],actual=str(out),expected='>=0; zero<=valid',difference='',tolerance='0',kind='integer'))
    status='SIN_REGISTROS' if n[i]==0 else 'SIN_VALORES_VALIDOS' if vv[i]==0 else 'SUMA_PARCIAL' if vv[i]<n[i] else 'OBSERVADO'
    statuses.append(status)
    if vv[i]==0:ss[i]=None;rawsum[ops['sum']['indicator_id']][i]=None
   ops['sum']['missingness']=dict(partial_municipalities=sum(x=='SUMA_PARCIAL' for x in statuses),no_valid_municipalities=sum(x in ['SIN_REGISTROS','SIN_VALORES_VALIDOS'] for x in statuses),outside_range_records=sum(outside))
   ops['sum']['status_values']=statuses
 # Frequencies must partition each entire observed entity, not only declared categories.
 freq=defaultdict(list)
 for r in recipes:
  if r['operation']=='records' and r['expected_national'] is not None:freq[r['source_variable']].append(r)
 for f,rs in freq.items():
  expected=entity_counts[f.split('.')[0]]
  for i,k in enumerate(keyorder):
   actual=sum(values[r['indicator_id']][i] for r in rs);checks+=1
   if actual!=expected[i]:failures.append(dict(indicator_id=f,test='frequency_partition',department=k,actual=str(actual),expected=str(expected[i]),difference=str(actual-expected[i]),tolerance='0',kind='integer'))
 integer_fails=[f for f in failures if f['kind']=='integer'];real_fails=[f for f in failures if f['kind']=='real']
 summary=dict(created=now(),checks=checks,indicators=len(recipes),municipalities=339,departments=9,integrity_and_counts_status='FAIL' if integer_fails else 'PASS',scientific_status='FAIL' if failures else 'PASS',integer_failures=len(integer_fails),real_reconciliation_failures=len(real_fails),maximum_real_difference=max([abs(float(f['difference'])) for f in real_fails] or [0]),failures=failures,raw_values_adjusted=False,independent_official_validation='Not yet evaluated; internal independent departmental totals and national frequency controls used')
 save(E/'validation.json',summary)
 if failures:outcsv(D/'validation_discrepancies.csv',failures)
 else:outcsv(D/'validation_discrepancies.csv',[],['indicator_id','test','department','actual','expected','difference','tolerance','kind'])
 assert not integer_fails,('Integrity/count failures prohibit integration',len(integer_fails))
 for r in recipes:
  f=r['source_variable'];code=r['context_code']
  if r['operation']=='holdings':r['label']=r['label'].replace(' · UPA únicas',' · UPA con esta respuesta registrada')
  if r['entity'] in ['BOVINO','OVINO','PORCINOG','PORCINOC','CAPRINO','LLAMA','ALPACA'] and f==r['entity']+'.'+KEYS[r['entity']]:
   r['record_interpretation']='La existencia de una fila de edad o sexo no implica cantidad positiva de animales. Para medir presencia de animales usar el indicador de UPA con cantidad positiva de la variable cuantitativa correspondiente.'
  if f=='AVESG.S6_P73_2':
   r['reference_period']='día de la entrevista CNA2013'
   r['source_imputation_note']='El metadato oficial documenta conversión automática de blancos a cero en esta variable. No se puede distinguir esos ceros de respuestas originales con los campos disponibles.'
   r['source_metadata_url']='https://fm.ine.gob.bo/index.php/catalog/229/variable/F14/V653?name=S6_P73_2'
  if r['entity']=='NROEMPL':
   r['reference_period']='año agrícola referido por el CNA2013'
   r['source_metadata_url']='https://anda.ine.gob.bo/index.php/catalog/229/variable/F35/V967?name=S14_P124_1A'
   if f in QUANT:
    r['source_imputation_note']='El manual pide registrar cero en casillas sin información; la base no permite separar esos casos. Se excluye el servicio doméstico del hogar; se incluye personal de apoyo a la actividad productiva.'
    r['source_imputation_note_en']='The interviewer manual prescribes zero for cells lacking information. Household domestic service is excluded; support staff serving productive activity is included.'
  if f in QUANT and r['entity'] in KEYS and r['context']!='species_total':
   key=r['entity']+'.'+KEYS[r['entity']]
   if not any(c['code']==code for c in C[key]):
    r['statistical_role']='diagnostic';r['semantic_limit']='Cantidad por código sin etiqueta declarada; significado del grupo no supuesto.'
    if key in ['PORCINOG.S6_P55A','PORCINOC.S6_P57A'] and code=='01':
     r['semantic_limit']='Fila 01 sin etiqueta: igualdad exacta observada con suma de grupos 02/03/04. No sumar esta fila a sus componentes; totales de especie usan solo grupos etiquetados.'
  if r['operation'] in ['records','holdings'] and f in V and not r.get('coverage_residual'):
   declared=any(c['code']==code for c in C[f])
   numeric_frequency=f in NUMERIC_FREQUENCIES
   if C[f] and not declared and not numeric_frequency:
    r['statistical_role']='diagnostic';r['semantic_limit']='Código observado sin etiqueta declarada; significado no supuesto.'
   elif not C[f] and V[f]['type_effective']=='INTEGER' and f!='GANADERIA.S6_P43':
    bounds=json.loads(V[f]['ranges_json'])
    if bounds and max(float(b['max']) for b in bounds)<=9:
     r['statistical_role']='diagnostic';r['semantic_limit']='Pregunta categórica con códigos sin etiquetas en este diccionario.'
   if f in CALENDAR_FIELDS and code in ['0','9999']:
    r['statistical_role']='diagnostic';r['semantic_limit']='Código de año no interpretable como fecha efectiva.'
   if (f=='COMPFAM.S15_P129_2' and code=='999') or (f=='COMPFAM.S15_P129_4' and code=='99'):
    r['statistical_role']='diagnostic';r['semantic_limit']='Valor extremo sin etiqueta sustantiva ni codificación de no respuesta resuelta; se conserva como diagnóstico, no como años efectivos.'
   if numeric_frequency and r['statistical_role']=='analytical':
    raw_label=f'Código {code} (sin etiqueta)'
    display=code+(' años' if f in ['COMPFAM.S15_P129_2','COMPFAM.S15_P129_4'] else '')
    r['label']=r['label'].replace(raw_label,display)
  if r['source_variable']=='COMUNIDAD' and r['operation']=='entity_records':
   r['statistical_role']='analytical';r['label']='Comunidades censales registradas'
  r['validation_failures']=sum(x['indicator_id']==r['indicator_id'] for x in failures)
  r['status']='RECONCILIATION_DISCREPANCY' if r['validation_failures'] else 'INTERNAL_CONTROLS_PASS'
  r['national_total']=r['raw_national_total'] if any(x is not None for x in values[r['indicator_id']]) else None
 groups=defaultdict(list)
 for r in recipes:groups[r['group']].append(r)
 save(D/'indicators.json',recipes)
 public=[]
 for r in recipes:public.append({k:(json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list)) else v) for k,v in r.items() if k!='status_values'})
 fields=list(dict.fromkeys(k for r in public for k in r));outcsv(D/'variable_dictionary.csv',[{k:r.get(k,'') for k in fields} for r in public],fields)
 for group,rs in groups.items():
  blob=dict(keys=keyorder,variables={r['indicator_id']:values[r['indicator_id']] for r in rs},status={r['indicator_id']:r['status_values'] for r in rs if 'status_values' in r})
  save(D/'Modules'/f'{group}.json',blob)
  cols=['municipio_id','departamento','provincia','municipio','year']+[r['indicator_id'] for r in rs]
  rows=[dict(municipio_id=k,departamento=geo[k]['nombredepartamento'],provincia=geo[k]['provincia'],municipio=geo[k]['municipio'],year=2013,**{r['indicator_id']:rawsum.get(r['indicator_id'],values[r['indicator_id']])[i] for r in rs}) for i,k in enumerate(keyorder)]
  outcsv(D/'Modules'/f'{group}.csv',rows,cols)
 # Stream the wide table: no duplicated giant row dictionaries.
 p=D/'municipal_full_wide.csv';tmp=p.with_suffix('.csv.tmp')
 with tmp.open('w',encoding='utf-8',newline='') as file:
  w=csv.writer(file);w.writerow(['municipio_id','departamento','provincia','municipio','year']+[r['indicator_id'] for r in recipes])
  for i,k in enumerate(keyorder):w.writerow([k,geo[k]['nombredepartamento'],geo[k]['provincia'],geo[k]['municipio'],2013]+[rawsum.get(r['indicator_id'],values[r['indicator_id']])[i] for r in recipes])
 os.replace(tmp,p)
 save(E/'export_summary.json',dict(created=now(),indicators=len(recipes),analytical=sum(r['statistical_role']=='analytical' for r in recipes),diagnostic=sum(r['statistical_role']=='diagnostic' for r in recipes),groups={g:len(rs) for g,rs in groups.items()},total_columns=5+len(recipes)))
 print('EXPORT COMPLETE',len(recipes),'indicators;',len(failures),'documented discrepancies')
if __name__=='__main__':run()
