"""Generate municipal and independent departmental raw aggregates with per-indicator recipes."""
from specification import *
import re,shutil,itertools

def run():
 domains=json.loads((E/'observed_domains.json').read_text(encoding='utf-8'));specs=[];schema_hash=sha(BASE/'schema.json')
 oldrecipes={r['indicator_id']:r for r in json.loads((E/'recipes.json').read_text(encoding='utf-8'))} if (E/'recipes.json').exists() else {}
 def add(f,context,condition,kind,unit,label,role='analytical',expected=None,context_code='',context_label=''):
  ent=f.split('.')[0];token=re.sub('[^a-z0-9]+','_',f.lower())
  iid='cna13b_'+token+'_'+context+'_'+kind
  specs.append(dict(indicator_id=iid,source_variable=f,entity=ent,group=ENTITY_GROUP[ent],context=context,context_code=context_code,context_label=context_label,filter=condition,operation=kind,unit=unit,label=label,statistical_role=role,expected_national=expected,reference_period=period(f),denominator='no aplica: conteo o suma cruda',source_schema_sha256=schema_hash))
 # Frequencies use observed exact codes, including unlabelled codes without invented meanings.
 for f,dom in domains.items():
  ent=V[f]['entity']
  for j,c in enumerate(dom['categories']):
   cond=f'MISSING({f})' if c['special']=='missing' else f'NOTAPPLICABLE({f})' if c['special']=='not_applicable' else comparison(f,c['code'])
   label=V[f]['label']+' · '+(c['label'] or 'vacío')
   role='diagnostic' if c['nonresponse'] else 'analytical'
   for kind,unit in [('records','registros' if ent!='UPA' else 'UPA'),('holdings','UPA')]:
    add(f,f'c{j:04d}',cond,kind,unit,label+(' · registros' if kind=='records' else ' · UPA únicas'),role,c['count'] if kind=='records' else None,c['code'],c['label'])
 # Quantities: always split by product/species/equipment where units or meanings differ.
 for f,unit in QUANT.items():
  ent=V[f]['entity'];contexts=[('all','','Total del campo',None)]
  if ent in KEYS:
   k=ent+'.'+KEYS[ent];contexts=[(f'c{i:04d}',comparison(k,c['code']),c['label'] or c['code'],c['code']) for i,c in enumerate(domains[k]['categories']) if not c['special']]
  elif ent=='NROEMPL':
   contexts=[]
   for c,d in itertools.product(domains['NROEMPL.S14_P123']['categories'],domains['NROEMPL.S14_P12A']['categories']):
    if c['special'] or d['special']:continue
    contexts.append(('c'+c['code']+'_'+d['code'],f'NROEMPL.S14_P123 = {c["code"]} AND NROEMPL.S14_P12A = {d["code"]}',c['label']+' · '+d['label'],c['code']+'|'+d['code']))
  elif f=='GANADERIA.S6_P81A':
   k='GANADERIA.S6_P81B';contexts=[(f'c{i:04d}',comparison(k,c['code']),'Unidad registrada: '+c['code'],c['code']) for i,c in enumerate(domains[k]['categories']) if not c['special']]
  for context,base,label,code in contexts:
   actual_unit=('ha' if code=='5' else 'km' if code=='6' else 'unidades') if ent=='CONSTRUCCION' else (str(code) if f=='GANADERIA.S6_P81A' else unit)
   prefix=V[f]['label']+' · '+label
   for kind,u in [('records','registros'),('valid','registros'),('missing','registros'),('not_applicable','registros'),('zero','registros'),('sum',actual_unit),('holdings_valid','UPA'),('holdings_positive','UPA')]:
    add(f,context,base,kind,u,prefix+' · '+{'records':'registros','valid':'registros válidos','missing':'faltantes nativos','not_applicable':'no aplica','zero':'ceros observados','sum':'suma','holdings_valid':'UPA con cantidad válida','holdings_positive':'UPA con cantidad positiva'}[kind],'analytical' if kind in ['sum','holdings_positive'] else 'diagnostic',None,code or '',label)
 # Cardinality and geographic coverage, without exposing identifiers below municipalities.
 for ent in ['AREA','CANTON','COMUNIDAD']+list(ENTITY_GROUP):
  specs.append(dict(indicator_id='cna13b_'+ent.lower()+'_records',source_variable=ent,entity=ent,group=ENTITY_GROUP.get(ent,'structure'),context='entity',context_code='',context_label='',filter='',operation='entity_records',unit='comunidades' if ent=='COMUNIDAD' else 'registros',label=ent+' · registros censales',statistical_role='diagnostic',expected_national=None,reference_period='CNA2013',denominator='no aplica: conteo crudo',source_schema_sha256=schema_hash))
 assert len(specs)==len({s['indicator_id'] for s in specs})
 bygroup=defaultdict(list)
 for s in specs:bygroup[s['group']].append(s)
 queue=[];allrecipes=[]
 for group,items in bygroup.items():
  for start in range(0,len(items),160):
   batch=f'full_{group}_{start//160:03d}';part=items[start:start+160]
   if any(V[f]['type_effective']=='STRING' for f in domains if ENTITY_GROUP[V[f]['entity']]==group):batch+='_v4'
   defs=[];cols=[];recipes=[]
   for i,s in enumerate(part,1):
    s=dict(s);f=s['source_variable'];ent=s['entity'];kind=s['operation'];base=s['filter'];cond=base;pre='';column='V'+str(i)
    if kind in ['valid','zero','sum','holdings_valid','holdings_positive']:
     cond=(f'({base}) AND ' if base else '')+valid(f)
     if kind=='zero':cond+=' AND '+f+' = 0'
     if kind=='holdings_positive':cond+=' AND '+f+' > 0'
    elif kind in ['missing','not_applicable']:cond=(f'({base}) AND ' if base else '')+('MISSING' if kind=='missing' else 'NOTAPPLICABLE')+'('+f+')'
    suffix=' FILTER '+cond if cond else ''
    if kind.startswith('holdings'):
     if ent=='UPA':expr='COUNT UPA'+suffix
     else:
      pre=f'DEFINE UPA.R{i} AS COUNT {ent}'+suffix+' TYPE INTEGER'
      expr=f'COUNT UPA FILTER UPA.R{i} > 0'
    elif kind=='sum':expr='SUM '+f+suffix
    else:expr='COUNT '+ent+suffix
    code=f'DEFINE MUNIC.{column} AS {expr} TYPE '+('REAL DECIMALS 6' if kind=='sum' else 'INTEGER')
    if pre:defs.append(pre)
    defs.append(code);cols.append('MUNIC.'+column)
    version='_v4' if batch.endswith('_v4') else ''
    s.update(redatam_column=column,redatam_code=code,prerequisites=pre,execution_program=batch+'_m.spc',execution_result=batch+'_m.csv',reproduction_program=s['indicator_id']+version+'.spc',status='GENERATED',integer_expected=kind!='sum' or V[f]['type_effective']=='INTEGER',effective_filter=cond)
    recipes.append(s)
   for suffix,level,nrows in [('m','MUNIC',339),('d','DEPTO',9)]:
    name=batch+'_'+suffix;output=E/'Results'/f'{name}.csv'
    body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(cols).replace('MUNIC.',level+'.')+f'\n OUTPUTFILE CSV "{output}" UTF8'
    p=program(name,body);save(E/'Plans'/f'{name}.json',dict(name=name,group=group,level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(output),rows=nrows,columns=len(cols)+1)],recipes=recipes))
    shutil.copy2(p,D/'Programs'/p.name);queue.append(name)
   for s in recipes:
    old=oldrecipes.get(s['indicator_id'])
    if old and all(old.get(k)==s.get(k) for k in ['redatam_code','prerequisites','execution_program','reproduction_program']):
     s.update(program_sha256=old['program_sha256'],reproduction_sha256=old['reproduction_sha256']);allrecipes.append(s);continue
    p=D/'Recipes'/s['reproduction_program'];out=E/'RecipeRuns'/(s['indicator_id']+'.csv')
    write(p,f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+s['prerequisites']+'\n'+s['redatam_code']+'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.'+s['redatam_column']+f'\n OUTPUTFILE CSV "{out}" UTF8\n')
    s.update(program_sha256=sha(E/'Programs'/s['execution_program']),reproduction_sha256=sha(p));allrecipes.append(s)
 save(E/'queue.json',queue);save(E/'recipes.json',allrecipes);outcsv(D/'variable_dictionary.csv',allrecipes)
 save(E/'generation.json',dict(created=now(),indicators=len(allrecipes),batches=len(queue),groups={g:len(x) for g,x in bygroup.items()},source_fields=329,scope='Univariate observed-code frequencies and physical quantities by native product/equipment/age group; employment by pay/activity. Not all possible multivariate cross-products.'))
 print('Generated',len(allrecipes),'indicators;',len(queue),'municipal/department programs')
if __name__=='__main__':run()
