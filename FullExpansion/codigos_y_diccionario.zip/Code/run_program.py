"""Bounded resumable native engine execution; stable output is not scientific acceptance."""
from common import *
import subprocess,time,sys,threading
VERIFY_LOCK=threading.Lock()
VERIFIED_SOURCES={}

def verify_sources():
 with VERIFY_LOCK:
  if not VERIFIED_SOURCES:
   for f in json.loads((BASE/'source_manifest.json').read_text(encoding='utf-8'))['files']:
    p=W/f['filename'];assert sha(p)==f['sha256'];VERIFIED_SOURCES[str(p)]=(p.stat().st_size,p.stat().st_mtime_ns)
   save(E/'source_verification.json',dict(created=now(),status='PASS',files=len(VERIFIED_SOURCES),method='All working-copy source hashes verified at queue startup; size/mtime guards before each batch; original Inputs never modified'))
  else:
   for path,signature in VERIFIED_SOURCES.items():
    p=Path(path);assert (p.stat().st_size,p.stat().st_mtime_ns)==signature,path
def run(name):
 cfg=json.loads((E/'Plans'/f'{name}.json').read_text(encoding='utf-8'));spc=E/'Programs'/f'{name}.spc';assert sha(spc)==cfg['program_sha256'];receipt=E/'Results'/f'{name}_run.json'
 if receipt.exists():
  old=json.loads(receipt.read_text(encoding='utf-8'))
  if old['export_complete_stable'] and all(sha(Path(x['path']))==x['sha256'] for x in old['outputs']):print('RESUME_SKIP',name,flush=True);return old
  raise RuntimeError('Existing incomplete receipt: use a versioned retry')
 outputs=cfg['outputs'];assert all(not Path(o['path']).exists() for o in outputs)
 verify_sources()
 si=subprocess.STARTUPINFO();si.dwFlags|=subprocess.STARTF_USESHOWWINDOW;si.wShowWindow=0
 cmd=[str(EXE),str(spc),'X'];start=time.monotonic();stable=0;last=None;complete=False;terminated=False;log=E/'Results'/f'{name}_engine.log'
 with log.open('wb') as capture:
  process=subprocess.Popen(cmd,cwd=E/'Results',stdout=capture,stderr=subprocess.STDOUT,startupinfo=si,creationflags=subprocess.CREATE_NO_WINDOW)
  save(E/f'active_{name}.json',dict(active=True,pid=process.pid,name=name,started=now()))
  while time.monotonic()-start<cfg.get('timeout_seconds',1800):
   signatures=[]
   for output in outputs:
    p=Path(output['path'])
    try:
     rows=read(p,';');keys=[r['REDCODE'] for r in rows]
     good=len(rows)==output['rows'] and len(set(keys))==len(keys) and all(len(r)==output.get('columns',len(rows[0])) and len(r)>=output.get('min_columns',2) and None not in r and all(v is not None and (v!='' or output.get('allow_empty_categories',False)) for v in r.values()) for r in rows)
     if good:signatures.append((p.stat().st_size,p.stat().st_mtime_ns,sha(p)))
    except (OSError,ValueError,KeyError,UnicodeError,csv.Error):pass
   for extra in cfg.get('extra_files',[]):
    try:
     p=Path(extra)
     if p.stat().st_size>0:signatures.append((p.stat().st_size,p.stat().st_mtime_ns,sha(p)))
    except OSError:pass
   signature=tuple(signatures) if len(signatures)==len(outputs)+len(cfg.get('extra_files',[])) else None;stable=stable+1 if signature and signature==last else 0;last=signature
   if signature and stable>=5:
    complete=True
    if process.poll() is None:process.terminate();terminated=True
    break
   if process.poll() is not None:break
   time.sleep(2)
  if process.poll() is None:process.kill();terminated=True
  process.wait(timeout=15)
 result=dict(created=now(),name=name,command=cmd,pid=process.pid,seconds=time.monotonic()-start,exit_code=process.returncode,export_complete_stable=complete,owned_process_terminated=terminated,normal_exit_verified=not terminated and process.returncode==0,program_sha256=sha(spc),engine_sha256=sha(EXE),outputs=[dict(path=o['path'],sha256=sha(Path(o['path']))) for o in outputs if Path(o['path']).exists()],status='EXPORT_COMPLETE_PENDING_VALIDATION' if complete else 'FAILED_OR_INCOMPLETE')
 result['outputs'] += [dict(path=x,sha256=sha(Path(x))) for x in cfg.get('extra_files',[]) if Path(x).exists()]
 save(receipt,result);save(E/f'active_{name}.json',dict(active=False,last_status=result['status']));print(name,result['status'],round(result['seconds'],1),'seconds',flush=True)
 if not complete:raise RuntimeError('Incomplete export: inspect log and version retry')
 return result
if __name__=='__main__':run(sys.argv[1])
