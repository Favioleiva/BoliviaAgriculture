"""Version the residual batch using equivalent compact integer intervals."""
from specification import *
import shutil

def run():
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'));domains=json.loads((E/'observed_domains.json').read_text(encoding='utf-8'))
 part=[dict(r) for r in recipes if r.get('coverage_residual')];assert len(part)==26
 name='coverage_residuals_v2';assert not (E/'Plans'/(name+'_m.json')).exists()
 for r in part:
  f=r['source_variable'];cats=domains[f]['categories'];assert V[f]['type_effective']=='INTEGER'
  old=' OR '.join('('+comparison(f,c['code'])+')' for c in cats)
  codes=sorted(int(c['code']) for c in cats);spans=[]
  for c in codes:
   if spans and c==spans[-1][1]+1:spans[-1][1]=c
   else:spans.append([c,c])
  assert [n for a,b in spans for n in range(a,b+1)]==codes
  compact=' OR '.join('('+f+' = '+str(a)+')' if a==b else f'({f} >= {a} AND {f} <= {b})' for a,b in spans)
  assert old in r['prerequisites'];r['prerequisites']=r['prerequisites'].replace(old,compact)
  r['execution_program']=name+'_m.spc';r['execution_result']=name+'_m.csv';r['reproduction_program']=r['indicator_id']+'_v2.spc'
  out=E/'RecipeRuns'/(r['indicator_id']+'_v2.csv');p=D/'Recipes'/r['reproduction_program']
  write(p,f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+r['prerequisites']+'\n'+r['redatam_code']+'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.'+r['redatam_column']+f'\n OUTPUTFILE CSV "{out}" UTF8\n');r['reproduction_sha256']=sha(p)
 defs=[]
 for r in part:defs.extend([r['prerequisites'],r['redatam_code']])
 queue=[]
 for suffix,level,rows in [('m','MUNIC',339),('d','DEPTO',9)]:
  batch=name+'_'+suffix;out=E/'Results'/(batch+'.csv')
  body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(level+'.'+r['redatam_column'] for r in part)+f'\n OUTPUTFILE CSV "{out}" UTF8'
  p=program(batch,body);shutil.copy2(p,D/'Programs'/p.name)
  save(E/'Plans'/(batch+'.json'),dict(name=batch,group='coverage_diagnostics',level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(out),rows=rows,columns=len(part)+1)],recipes=part));queue.append(batch)
 for r in part:r['program_sha256']=sha(E/'Programs'/r['execution_program'])
 replace={r['indicator_id']:r for r in part};save(E/'History/recipes_before_coverage_v2.json',recipes)
 save(E/'recipes.json',[replace.get(r['indicator_id'],r) for r in recipes]);save(E/'coverage_queue.json',queue)
 save(E/'queue.json',[n.replace('coverage_residuals_','coverage_residuals_v2_') if n.startswith('coverage_residuals_') else n for n in json.loads((E/'queue.json').read_text(encoding='utf-8'))])
 save(E/'coverage_retry.json',dict(created=now(),reason='Native process crashed while parsing a long chain of OR comparisons (exit 3221225477). Consecutive integer codes compacted into exactly equivalent intervals, verified by expanding spans; no new codes included.',version=2))
 print('Version 2 generated with exact interval equivalence.')

if __name__=='__main__':run()
