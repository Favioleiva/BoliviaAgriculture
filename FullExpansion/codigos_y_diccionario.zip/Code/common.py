from pathlib import Path
import json,csv,hashlib,datetime,os,io
R=Path(__file__).resolve().parents[5];O=R/'Outputs/Contract_04';E=O/'Evidence/FullExpansion';D=O/'Deliverables/FullExpansion';BASE=O/'Evidence/RedatamExploration';W=BASE/'WorkBase';EXE=Path('C:/Program Files/Redatam7/RedProcess.exe')
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(8*1024*1024),b''):h.update(b)
 return h.hexdigest()
def write(p,s):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(s,encoding='utf-8');os.replace(t,p)
def save(p,x):write(p,json.dumps(x,ensure_ascii=False,indent=2,allow_nan=False))
def read(p,sep=','):
 with Path(p).open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=sep))
def outcsv(p,rows,fields=None):
 f=io.StringIO(newline='');w=csv.DictWriter(f,fieldnames=fields or list(rows[0]),lineterminator='\n');w.writeheader();w.writerows(rows);write(p,f.getvalue())
def program(name,body,selection='ALL'):
 p=E/'Programs'/f'{name}.spc';s=f'RUNDEF {name}\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION {selection}\n NOWEIGHT\n\n'+body+'\n'
 if p.exists():assert p.read_text(encoding='utf-8')==s
 else:write(p,s)
 return p
