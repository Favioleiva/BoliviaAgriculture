"""Two independent, bounded local engines maximum, with restartable receipts."""
from common import *
from run_program import run
from concurrent.futures import ThreadPoolExecutor,as_completed
import sys,traceback
def main():
 queue=json.loads(Path(sys.argv[1]).read_text(encoding='utf-8'));results=[]
 with ThreadPoolExecutor(max_workers=2) as pool:
  jobs={pool.submit(run,name):name for name in queue}
  for future in as_completed(jobs):
   name=jobs[future]
   try:r=future.result();results.append(dict(name=name,complete=r['export_complete_stable']))
   except Exception as e:results.append(dict(name=name,complete=False,error=str(e)));traceback.print_exc()
   save(E/(Path(sys.argv[1]).stem+'_progress.json'),dict(created=now(),completed=results,total=len(queue)))
 print('QUEUE_COMPLETE',len(results),sum(r['complete'] for r in results),flush=True)
 if not all(r['complete'] for r in results):raise RuntimeError('Some bounded batches require review; no automatic overwrite')
if __name__=='__main__':main()
