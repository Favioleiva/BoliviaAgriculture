"""Species totals and producer-specific counts, without summing holdings across categories."""
from specification import *
import shutil

def run():
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'));assert not any(r['context']=='species_total' for r in recipes),'Already generated'
 schema_hash=sha(BASE/'schema.json');new=[];domains=json.loads((E/'observed_domains.json').read_text(encoding='utf-8'))
 names=dict(BOVINO='Bovinos sin bueyes',OVINO='Ovinos',PORCINOG='Porcinos de granja',PORCINOC='Porcinos de corral',CAPRINO='Caprinos',LLAMA='Llamas',ALPACA='Alpacas')
 for f,unit in QUANT.items():
  ent=V[f]['entity']
  if ent not in names:continue
  base='BOVINO.S6_P41A >= 3 AND BOVINO.S6_P41A <= 11' if ent=='BOVINO' else ''
  for kind,u in [('records','registros'),('valid','registros'),('missing','registros'),('not_applicable','registros'),('zero','registros'),('sum',unit),('holdings_valid','UPA'),('holdings_positive','UPA')]:
   new.append(dict(indicator_id='cna13b_'+f.lower().replace('.','_')+'_species_total_'+kind,source_variable=f,entity=ent,group='livestock',context='species_total',context_code='ALL_EXCEPT_OXEN' if ent=='BOVINO' else 'ALL',context_label=names[ent]+' · todos los grupos',filter=base,operation=kind,unit=u,label=names[ent]+' · '+V[f]['label']+' · '+{'records':'registros','valid':'registros válidos','missing':'faltantes','not_applicable':'no aplica','zero':'ceros','sum':'cabezas totales','holdings_valid':'UPA con dato válido','holdings_positive':'UPA con cantidad positiva'}[kind],statistical_role='analytical' if kind in ['sum','holdings_positive'] else 'diagnostic',expected_national=None,reference_period='Existencias al momento de la entrevista CNA2013',denominator='no aplica: conteo o suma cruda',source_schema_sha256=schema_hash))
 for field in ['S15_P129_2','S15_P129_3','S15_P129_4','S15_P129_5','S15_P129_6','S15_P129_7']:
  f='COMPFAM.'+field
  for j,c in enumerate(domains[f]['categories']):
   if c['special']:continue
   base=f'COMPFAM.S15_P129_1 = 1 AND {f} = {literal(f,c["code"])}'
   for kind,unit in [('records','productores registrados'),('holdings','UPA')]:
    new.append(dict(indicator_id='cna13b_'+f.lower().replace('.','_')+f'_producer_c{j:04d}_'+kind,source_variable=f,entity='COMPFAM',group='workforce',context=f'producer_c{j:04d}',context_code=c['code'],context_label='Productor(a) · '+c['label'],filter=base,operation=kind,unit=unit,label='Productor(a) · '+V[f]['label']+' · '+c['label']+' · '+('registros' if kind=='records' else 'UPA únicas'),statistical_role='diagnostic' if c['nonresponse'] else 'analytical',expected_national=None,reference_period='CNA2013; solo parentesco=Productor(a)',denominator='no aplica: conteo crudo',source_schema_sha256=schema_hash))
 queue=[]
 for start in range(0,len(new),160):
  batch=f'extra_totals_{start//160:03d}';part=new[start:start+160];defs=[];cols=[]
  for i,s in enumerate(part,1):
   f=s['source_variable'];ent=s['entity'];kind=s['operation'];base=s['filter'];cond=base;pre='';column='V'+str(i)
   if kind in ['valid','zero','sum','holdings_valid','holdings_positive']:
    cond=(f'({base}) AND ' if base else '')+valid(f)
    if kind=='zero':cond+=' AND '+f+' = 0'
    if kind=='holdings_positive':cond+=' AND '+f+' > 0'
   elif kind in ['missing','not_applicable']:cond=(f'({base}) AND ' if base else '')+('MISSING' if kind=='missing' else 'NOTAPPLICABLE')+'('+f+')'
   suffix=' FILTER '+cond if cond else ''
   if kind.startswith('holdings'):
    pre=f'DEFINE UPA.R{i} AS COUNT {ent}'+suffix+' TYPE INTEGER';expr=f'COUNT UPA FILTER UPA.R{i} > 0'
   elif kind=='sum':expr='SUM '+f+suffix
   else:expr='COUNT '+ent+suffix
   code=f'DEFINE MUNIC.{column} AS {expr} TYPE '+('REAL DECIMALS 6' if kind=='sum' else 'INTEGER')
   if pre:defs.append(pre)
   defs.append(code);cols.append('MUNIC.'+column)
   s.update(redatam_column=column,redatam_code=code,prerequisites=pre,execution_program=batch+'_m.spc',execution_result=batch+'_m.csv',reproduction_program=s['indicator_id']+'.spc',status='GENERATED',integer_expected=True,effective_filter=cond)
  for suffix,level,nrows in [('m','MUNIC',339),('d','DEPTO',9)]:
   name=batch+'_'+suffix;output=E/'Results'/f'{name}.csv';body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(cols).replace('MUNIC.',level+'.')+f'\n OUTPUTFILE CSV "{output}" UTF8'
   p=program(name,body);save(E/'Plans'/f'{name}.json',dict(name=name,group='mixed_supplements',level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(output),rows=nrows,columns=len(cols)+1)],recipes=part));shutil.copy2(p,D/'Programs'/p.name);queue.append(name)
  for s in part:
   p=D/'Recipes'/s['reproduction_program'];out=E/'RecipeRuns'/(s['indicator_id']+'.csv')
   write(p,f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+s['prerequisites']+'\n'+s['redatam_code']+'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.'+s['redatam_column']+f'\n OUTPUTFILE CSV "{out}" UTF8\n')
   s.update(program_sha256=sha(E/'Programs'/s['execution_program']),reproduction_sha256=sha(p))
 assert len({r['indicator_id'] for r in recipes+new})==len(recipes+new)
 save(E/'recipes.json',recipes+new);save(E/'supplement_queue.json',queue);save(E/'queue.json',json.loads((E/'queue.json').read_text())+queue)
 save(E/'supplements.json',dict(created=now(),indicators=len(new),programs=len(queue),purpose='Species owning holdings are counted once across age groups; producer characteristics filter COMPFAM kinship code 1.'))
 print('Supplement:',len(new),'indicators;',len(queue),'programs')
if __name__=='__main__':run()
