"""Check delivered values, navigation, rankings, local downloads and visual layouts."""
from common import *
from playwright.sync_api import sync_playwright
import re,collections

def run():
 ui=O/'Deliverables/Agro2013';rs=json.loads((D/'indicators.json').read_text(encoding='utf-8'))
 modules={g:json.loads((D/'Modules'/f'{g}.json').read_text(encoding='utf-8')) for g in {r['group'] for r in rs}}
 checks=[];errors=[];failed=[];screens=[]
 def payload(p):return json.loads(re.search(r'<script id="payload" type="application/json">(.*?)</script>',p.read_text(encoding='utf-8'),re.S)[1])
 before=payload(E/'History'/ui.relative_to(R)/'index.html');after=payload(ui/'index.html')
 assert before['rows']==after['rows'];assert before['variables']==after['variables'][:len(before['variables'])]
 assert len({v['variable'] for v in after['variables']})==len(after['variables'])
 assert len(after['cropCatalog'])==611
 checks.append('All previous rows and variable definitions preserved exactly; 611 crop codes preserved')
 with sync_playwright() as pw:
  browser=pw.chromium.launch(channel='msedge',headless=True)
  p=browser.new_page(viewport={'width':1440,'height':1000})
  p.on('pageerror',lambda e:errors.append(str(e)));p.on('requestfailed',lambda r:failed.append(r.url))
  p.goto((ui/'index.html').as_uri());p.evaluate('window.productsReady')
  assert p.locator('.rank-select').count()==10
  p.locator('.rank-select').first.click()
  assert p.locator('.rank-select[aria-pressed="true"]').count()==1
  assert p.locator('.municipality.selected').count()==1
  def choose(r):
   p.evaluate('''async id=>{const v=variableById.get(id);$('#topic').value=v.group;$('#fullRole').value=v.full_role;$('#fullSearch').value='';$('#fullField').replaceChildren();variableOptions(id);window.productsReady=loadAndUpdate();await window.productsReady}''',r['indicator_id'])
   assert p.locator('#animal').input_value()==r['indicator_id']
  for group,blob in sorted(modules.items()):
   candidates=[r for r in rs if r['group']==group and r['statistical_role']=='analytical']
   r=next((r for r in candidates if r['operation']=='sum'),candidates[0]);choose(r)
   # Compare every module value, including nulls, after loading via actual local JS.
   actual=p.evaluate('g=>Object.fromEntries(DATA.variables.filter(v=>v.group==="full_"+g).map(v=>[v.variable,fullValues.get(v.variable)]))',group)
   assert actual==blob['variables'],group
   assert not p.locator('#fullFieldLabel').evaluate('(e)=>e.hidden')
   assert p.locator('#measure').evaluate('(e)=>e.closest("label").hidden')
   ranking=p.evaluate('''()=>{const expected=DATA.rows.filter(r=>Number.isFinite(value(r))&&value(r)>0).sort((a,b)=>value(b)-value(a)).slice(0,10).map(r=>r.reference_code);return {expected,actual:[...document.querySelectorAll('.rank-select')].map(e=>e.dataset.code)}}''')
   assert ranking['actual']==ranking['expected'],group
   if ranking['actual']:
    last=p.locator('.rank-select').last;code=last.get_attribute('data-code');last.click()
    assert p.locator('.municipality.selected').get_attribute('data-code')==code
    last.focus();p.keyboard.press('Enter');assert last.get_attribute('aria-pressed')=='true'
   for selector in ['#fullData','#fullCode']:
    href=p.locator(selector).get_attribute('href');assert (ui/href).resolve().is_file(),href
   fields=p.locator('#fullField option').count()
   if fields>1:
    other=p.locator('#fullField option').nth(1).get_attribute('value');p.select_option('#fullField',other);p.evaluate('window.productsReady')
    assert p.evaluate('current().full_field')==other
   p.click('#en');assert p.locator('html').get_attribute('lang')=='en'
   p.click('#es');assert p.locator('html').get_attribute('lang')=='es'
   assert p.evaluate('document.documentElement.scrollWidth<=innerWidth'),group
   checks.append(dict(group=group,verified_values=len(actual)*339,ranking=ranking['actual'],navigation=True))
  # Real sparse/null cases, not synthetic changes to data.
  sparse=[];partial=None;null=None
  for r in rs:
   values=modules[r['group']]['variables'][r['indicator_id']];positive=sum(v is not None and v>0 for v in values)
   if positive in [0,1,5] and positive not in [x[0] for x in sparse]:sparse.append((positive,r))
   states=modules[r['group']]['status'].get(r['indicator_id'],[])
   if partial is None and 'SUMA_PARCIAL' in states:partial=(r,states.index('SUMA_PARCIAL'))
   if null is None and r['operation']=='sum' and None in values:null=(r,values.index(None))
  for count,r in sparse:
   choose(r);assert p.locator('.rank-select').count()==count
  for case,kind in [(partial,'partial'),(null,'null')]:
   if case:
    r,i=case;choose(r);code=modules[r['group']]['keys'][i]
    p.evaluate('code=>select(DATA.rows.find(r=>r.source_code===code).reference_code)',code)
    assert p.locator('#detailComponents').is_visible()
    if kind=='partial':assert 'parcial' in p.locator('#detailComponents').inner_text().lower()
    else:assert p.locator('#detailValue').inner_text()=='Sin dato'
  # Search and direct catalogue/deep-link navigation.
  r=next(r for r in rs if r['operation']=='sum' and r['group']=='agriculture');choose(r)
  assert p.evaluate('n(0.001,2).startsWith("<")')
  term=p.evaluate('current().es.split(" ").find(x=>x.length>3)');p.fill('#fullSearch',term);p.evaluate('window.productsReady')
  assert int(p.locator('#fullMatches').inner_text().split(':')[-1])>0
  assert p.evaluate('[...$("#animal").options].every(o=>fullNormalize(o.textContent).includes(fullNormalize($("#fullSearch").value)))')
  for width,label in [(1440,'desktop'),(390,'mobile')]:
   p.set_viewport_size({'width':width,'height':1000});assert p.evaluate('document.documentElement.scrollWidth<=innerWidth')
   p.locator('.hero').screenshot(path=str(E/f'hero_{label}.png'));screens.append(f'hero_{label}.png')
   p.locator('#explore').scroll_into_view_if_needed();p.screenshot(path=str(E/f'viewer_{label}.png'));screens.append(f'viewer_{label}.png')
   p.locator('.workspace').screenshot(path=str(E/f'map_and_ranking_{label}.png'));screens.append(f'map_and_ranking_{label}.png')
   assert p.locator('img[src="assets/hero-agriculture-v3.png"]').evaluate('(e)=>e.complete&&e.naturalWidth===1536')
  with p.expect_download() as download:p.click('#downloadMap')
  target=E/'sample_export.svg';download.value.save_as(target);assert '<svg' in target.read_text(encoding='utf-8')
  p.goto((D/'catalogo.html').as_uri()+'#'+r['indicator_id'])
  assert p.locator('article').count()==1
  p.get_by_role('link',name='Abrir en el mapa').click();p.wait_for_load_state('load');p.evaluate('window.productsReady')
  assert p.locator('#animal').input_value()==r['indicator_id']
  # Return to the legacy product and published animals after loading new modules.
  p.select_option('#topic','crops');p.evaluate('window.productsReady');assert p.evaluate('cropMode()')
  assert p.locator('#cropControls').is_visible();assert not p.locator('#fullFieldLabel').is_visible()
  p.select_option('#topic','animals');p.evaluate('window.productsReady');assert p.locator('.rank-select').count()==10
  assert not p.locator('#measure').evaluate('(e)=>e.closest("label").hidden')
  browser.close()
 assert not errors,errors;assert not failed,failed
 save(E/'browser_validation.json',dict(created=now(),status='PASS',checks=checks,sparse_ranking_counts=[x[0] for x in sparse],partial_case=bool(partial),null_case=bool(null),screenshots=screens,console_errors=errors,failed_requests=failed,visual_review='Pending image inspection'))
 print('Browser PASS:',sum(len(b['variables'])*339 for b in modules.values()),'values, 13 modules, desktop/mobile, navigation and preserved legacy views')

if __name__=='__main__':run()
