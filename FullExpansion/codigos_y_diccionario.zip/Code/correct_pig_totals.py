"""Version the supplemental batch after verifying overlapping pig total/age rows."""
from specification import *
from decimal import Decimal
import shutil

def run():
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'))
 prior={x['codmun']:x for x in read(O/'Deliverables/Agro2013/animal_population_native_2013.csv')}
 audit=[]
 for f in QUANT:
  ent=f.split('.')[0]
  if ent not in ['PORCINOG','PORCINOC']:continue
  rs=[r for r in recipes if r['source_variable']==f and r['operation']=='sum' and r['context']!='species_total']
  tables={r['execution_result']:{row['REDCODE']:row for row in read(E/'Results'/r['execution_result'],';')} for r in rs}
  rows=next(iter(tables.values()))
  def amount(r,code):return Decimal(tables[r['execution_result']][code][r['redatam_column']])
  total=next(r for r in rs if r['context_code']=='01');ages=[r for r in rs if r['context_code'] in ['02','03','04']]
  assert len(ages)==3
  discrepancies=[];published_discrepancies=[]
  for code,row in rows.items():
   summed=sum(amount(r,code) for r in ages)
   if summed!=amount(total,code):discrepancies.append(code)
   if f.endswith('B') and summed!=Decimal(prior[code]['porcino_granja' if ent=='PORCINOG' else 'porcino_corral']):published_discrepancies.append(code)
  assert not discrepancies and not published_discrepancies,(f,discrepancies,published_discrepancies)
  audit.append(dict(field=f,municipalities=339,code01_equals_age_sum=True,published_count_comparison='PASS' if f.endswith('B') else 'not applicable'))
 save(E/'pig_total_overlap_validation.json',dict(created=now(),status='PASS',checks=audit,decision='Use only the three explicitly labelled age groups 02/03/04 for species totals and owning holdings. Code01 remains a diagnostic, with exact equality to their sum observed. No guessed category label and no addition of total plus components.'))
 old='extra_totals_000';new=old+'_v2';part=json.loads((E/'Plans'/(old+'_m.json')).read_text(encoding='utf-8'))['recipes']
 assert not (E/'Plans'/(new+'_m.json')).exists(),'Version already created'
 changed=[]
 for r in part:
  if r['entity'] in ['PORCINOG','PORCINOC']:
   key=r['entity']+'.'+KEYS[r['entity']];base='('+ ' OR '.join(f'{key} = "{c}"' for c in ['02','03','04'])+')'
   r['filter']=base;r['context_code']='LABELLED_AGE_GROUPS_02_03_04';r['context_label']+=' · grupos 02/03/04; sin fila 01 superpuesta'
   oldcond=r['effective_filter'];r['effective_filter']=base+(' AND ('+oldcond+')' if oldcond else '')
   # Rebuild the expressions from semantics, preserving all unchanged components.
   f=r['source_variable'];kind=r['operation'];cond=r['effective_filter'];column=r['redatam_column'];i=column[1:]
   if kind.startswith('holdings'):
    r['prerequisites']=f'DEFINE UPA.R{i} AS COUNT {r["entity"]} FILTER {cond} TYPE INTEGER'
    expr=f'COUNT UPA FILTER UPA.R{i} > 0'
   elif kind=='sum':expr='SUM '+f+' FILTER '+cond
   else:expr='COUNT '+r['entity']+' FILTER '+cond
   r['redatam_code']=f'DEFINE MUNIC.{column} AS {expr} TYPE '+('REAL DECIMALS 6' if kind=='sum' else 'INTEGER')
   r['reproduction_program']=r['indicator_id']+'_v2.spc'
   out=E/'RecipeRuns'/(r['indicator_id']+'_v2.csv')
   write(D/'Recipes'/r['reproduction_program'],f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+r['prerequisites']+'\n'+r['redatam_code']+f'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.{column}\n OUTPUTFILE CSV "{out}" UTF8\n')
   r['reproduction_sha256']=sha(D/'Recipes'/r['reproduction_program']);changed.append(r['indicator_id'])
  r['execution_program']=new+'_m.spc';r['execution_result']=new+'_m.csv'
 defs=[]
 for r in part:
  if r['prerequisites']:defs.append(r['prerequisites'])
  defs.append(r['redatam_code'])
 for suffix,level,rows in [('m','MUNIC',339),('d','DEPTO',9)]:
  name=new+'_'+suffix;out=E/'Results'/(name+'.csv')
  body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(level+'.'+r['redatam_column'] for r in part)+f'\n OUTPUTFILE CSV "{out}" UTF8'
  p=program(name,body);shutil.copy2(p,D/'Programs'/p.name)
  save(E/'Plans'/(name+'.json'),dict(name=name,group='mixed_supplements',level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(out),rows=rows,columns=len(part)+1)],recipes=part))
 for r in part:r['program_sha256']=sha(E/'Programs'/(new+'_m.spc'))
 replacements={r['indicator_id']:r for r in part}
 save(E/'recipes.json',[replacements.get(r['indicator_id'],r) for r in recipes])
 queue=json.loads((E/'queue.json').read_text(encoding='utf-8'));save(E/'queue.json',[name.replace(old,new) if name.startswith(old+'_') else name for name in queue])
 save(E/'pig_correction_queue.json',[new+'_m',new+'_d'])
 save(E/'pig_correction.json',dict(created=now(),status='GENERATED_PENDING_EXECUTION',changed_indicators=changed,superseded_batch=old,canonical_batch=new,original_attempt_preserved=True))
 print('Verified pig overlapping rows; corrected',len(changed),'recipes in versioned 160-column batch. Execute m/d after current paired queue completes.')

if __name__=='__main__':run()
