"""Account explicitly for records not classified by native frequencies, without guessing codes."""
from specification import *
import shutil

def run():
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'))
 assert not any(r.get('coverage_residual') for r in recipes),'Already generated'
 domains=json.loads((E/'observed_domains.json').read_text(encoding='utf-8'))
 probe=json.loads((E/'coverage_probe_parsed.json').read_text(encoding='utf-8'))
 new=[];defs=[];fields=[]
 cases=[(p,False) for p in probe]+[(next(p for p in probe if p['field']=='COMPFAM.S15_P129_5'),True)]
 for p,producer in cases:
  f=p['field'];ent=V[f]['entity'];dom=domains[f]
  assert p['raw_total']==dom['total_records']
  residual=p['counts']['all']-p['raw_total'];assert residual>0
  known=' OR '.join('('+comparison(f,c['code'])+')' for c in dom['categories'])
  base='COMPFAM.S15_P129_1 = 1' if producer else ''
  cond='('+known+')';cond='('+base+') AND '+cond if base else cond
  for kind in ['records','holdings']:
   i=len(new)+1;column='V'+str(i);ctx='producer_unclassified' if producer else 'unclassified_native'
   iid='cna13b_'+f.lower().replace('.','_')+'_'+ctx+'_'+kind
   if ent=='UPA':
    pre=f'DEFINE MUNIC.A{i} AS COUNT UPA TYPE INTEGER\nDEFINE MUNIC.C{i} AS COUNT UPA FILTER {cond} TYPE INTEGER'
    expr=f'MUNIC.A{i} - MUNIC.C{i}'
   else:
    pre=f'DEFINE UPA.A{i} AS COUNT {ent}'+(' FILTER '+base if base else '')+f' TYPE INTEGER\nDEFINE UPA.C{i} AS COUNT {ent} FILTER {cond} TYPE INTEGER\nDEFINE UPA.D{i} AS UPA.A{i} - UPA.C{i} TYPE INTEGER'
    expr=f'SUM UPA.D{i}' if kind=='records' else f'COUNT UPA FILTER UPA.D{i} > 0'
   code=f'DEFINE MUNIC.{column} AS {expr} TYPE INTEGER'
   label=('Productor(a) · ' if producer else '')+V[f]['label']+' · registros no clasificados por la frecuencia nativa · '+('registros' if kind=='records' else 'UPA con algún registro no clasificado')
   r=dict(indicator_id=iid,source_variable=f,entity=ent,group=ENTITY_GROUP[ent],context=ctx,context_code='UNCLASSIFIED_NATIVE',context_label='Sin clasificación recuperable; no se presume cero, missing ni no aplicable',filter=base,operation=kind,unit='UPA' if kind=='holdings' or ent=='UPA' else 'registros',label=label,statistical_role='diagnostic',expected_national=residual if kind=='records' and not producer else None,reference_period=period(f),denominator='no aplica: conteo diagnóstico',source_schema_sha256=sha(BASE/'schema.json'),coverage_residual=True,semantic_limit='Diferencia entre registros totales y registros con alguno de los códigos recuperados por FREQUENCY. El motor tampoco los identifica con filtros MISSING(), NOTAPPLICABLE(), fuera de rango o 0. No se les atribuye código, respuesta sustantiva ni causa de ausencia. UPA afectadas se deduplican antes de agregar.',redatam_column=column,redatam_code=code,prerequisites=pre,execution_program='coverage_residuals_m.spc',execution_result='coverage_residuals_m.csv',reproduction_program=iid+'.spc',status='GENERATED',integer_expected=True,effective_filter='Por UPA: COUNT '+ent+(' FILTER '+base if base else '')+' menos COUNT de códigos recuperados; luego SUM del residual o COUNT de UPA con residual positivo')
   new.append(r);defs.extend([pre,code])
  fields.append(dict(field=f,producer_only=producer,native_classified_records=p['raw_total'],entity_records=p['counts']['all'],unclassified_records=residual,original_domain_unchanged=True))
 queue=[]
 for suffix,level,rows in [('m','MUNIC',339),('d','DEPTO',9)]:
  name='coverage_residuals_'+suffix;out=E/'Results'/(name+'.csv')
  body='\n'.join(defs).replace('MUNIC.',level+'.')+'\nTABLE RESULTA AS AREALIST OF '+level+', '+', '.join(level+'.'+r['redatam_column'] for r in new)+f'\n OUTPUTFILE CSV "{out}" UTF8'
  p=program(name,body);shutil.copy2(p,D/'Programs'/p.name)
  save(E/'Plans'/(name+'.json'),dict(name=name,group='coverage_diagnostics',level=level,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(out),rows=rows,columns=len(new)+1)],recipes=new));queue.append(name)
 for r in new:
  out=E/'RecipeRuns'/(r['indicator_id']+'.csv');p=D/'Recipes'/r['reproduction_program']
  write(p,f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+r['prerequisites']+'\n'+r['redatam_code']+'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.'+r['redatam_column']+f'\n OUTPUTFILE CSV "{out}" UTF8\n')
  r['program_sha256']=sha(E/'Programs'/r['execution_program']);r['reproduction_sha256']=sha(p)
 save(E/'History/recipes_before_coverage_diagnostics.json',recipes)
 save(E/'recipes.json',recipes+new);save(E/'coverage_queue.json',queue)
 save(E/'queue.json',json.loads((E/'queue.json').read_text(encoding='utf-8'))+queue)
 save(E/'coverage_resolution.json',dict(created=now(),status='GENERATED_PENDING_VALIDATION',diagnostic_indicators=len(new),fields=fields,method='Explicit coverage residual; not recovered raw categories. Totals checked against original national entity count minus native frequency and against all 339 municipal deficits. No existing category/count changed; no semantic imputation.',probes=['coverage_probe','coverage_special_equality'],limitations='Expanded temporary range did not recover additional values. Documented equality-to-special syntax failed in this installation and was stopped after parser stall; no result claimed. Underlying values remain unresolved.'))
 print('Generated',len(new),'explicit coverage diagnostics; native validation pending.')

if __name__=='__main__':run()
