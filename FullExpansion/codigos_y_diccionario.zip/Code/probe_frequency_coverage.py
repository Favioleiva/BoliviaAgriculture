"""Probe codes omitted by native frequencies without changing the dictionary."""
from specification import *
import shutil

def run():
 validation=json.loads((E/'validation.json').read_text(encoding='utf-8'))
 fields=sorted({r['indicator_id'] for r in validation['failures'] if r['test']=='frequency_partition'})
 assert len(fields)==12,fields
 history=E/'History/validation_before_coverage_repair.json'
 if not history.exists():shutil.copy2(E/'validation.json',history)
 defs=[];cols=[];extra=[];counts=[]
 for i,f in enumerate(fields):
  ent=V[f]['entity'];ranges=json.loads(V[f]['ranges_json']);assert V[f]['type_effective']=='INTEGER'
  low=min(int(x['min']) for x in ranges);high=max(int(x['max']) for x in ranges)
  upper=max(high,int(V[f]['missing'] or high),int(V[f]['not_applicable'] or high))+1
  assert 0<=low and upper<=10002,(f,low,upper)
  raw=ent+'.RAWN'+str(i)
  defs.append(f'DEFINE {raw} AS {f} TYPE INTEGER RANGE 0 - {upper}')
  stem=E/'Results'/f'coverage_probe_{i}';table='F'+str(i)
  defs.append(f'TABLE {table} AS FREQUENCY OF {raw}\n OUTPUTFILE HTML "{stem}.html" UTF8')
  extra.append(str(stem.parent/(stem.name+'_'+table+'.html')))
  inside=' OR '.join(f'({f} >= {x["min"]} AND {f} <= {x["max"]})' for x in ranges)
  conditions=[('all',''),('missing','MISSING('+f+')'),('not_applicable','NOTAPPLICABLE('+f+')'),('outside','NOT (('+inside+') OR MISSING('+f+') OR NOTAPPLICABLE('+f+'))'),('zero',f+' = 0'),('one',f+' = 1')]
  for kind,condition in conditions:
   col='V'+str(len(cols)+1);defs.append('DEFINE MUNIC.'+col+' AS COUNT '+ent+(' FILTER '+condition if condition else '')+' TYPE INTEGER');cols.append('MUNIC.'+col);counts.append(dict(field=f,kind=kind,column=col))
 name='coverage_probe';output=E/'Results'/(name+'.csv')
 defs.append('TABLE CHECKS AS AREALIST OF MUNIC, '+', '.join(cols)+f'\n OUTPUTFILE CSV "{output}" UTF8')
 p=program(name,'\n'.join(defs));save(E/'Plans'/(name+'.json'),dict(name=name,program_sha256=sha(p),timeout_seconds=1800,fields=fields,counts=counts,extra_files=extra,outputs=[dict(path=str(output),rows=339,columns=len(cols)+1)]))
 save(E/'coverage_probe_syntax.json',dict(created=now(),source='https://prod.redatam.org/redatam/rphelp/esp/Red7-02-Process-ESP.pdf',method='Temporary DEFINE AS expression TYPE INTEGER RANGE lower-upper, followed by FREQUENCY; original dictionary and input fields unchanged. Direct COUNT MISSING/NOTAPPLICABLE/outside-range/0/1 distinguishes excluded values.'))
 print('Probe generated for',len(fields),'fields; execute and validate expanded-range frequencies before extending extraction')

if __name__=='__main__':run()
