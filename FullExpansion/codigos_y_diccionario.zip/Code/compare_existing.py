"""Independent distribution checks against previously supplied municipal aggregates."""
from common import *
from decimal import Decimal
from collections import defaultdict
from specification import KEYS
def run():
 rs=json.loads((D/'indicators.json').read_text(encoding='utf-8'));groups={g:json.loads((D/'Modules'/(g+'.json')).read_text(encoding='utf-8')) for g in {r['group'] for r in rs}}
 olddict=read(O/'Deliverables/CategoryExpansion/canonical_variable_dictionary.csv');lookup={}
 for r in olddict:
  if r['irrigation']=='todos' and r['operation'] in ['registros','upa_con_registros']:
   lookup[(r['entity'],r['crop_code'],r['operation'])]=r['indicator_id']
 matches=[]
 for r in rs:
  if r['entity'] not in ['CULTINV','CULTVER','CULTSEM','CULTPAS','CULTFOR','CULTOTR'] or r['operation'] not in ['records','holdings'] or r['source_variable']!=r['entity']+'.'+KEYS[r['entity']] or r.get('coverage_residual'):continue
  op='registros' if r['operation']=='records' else 'upa_con_registros';prior=lookup.get((r['entity'],r['context_code'],op))
  if prior:matches.append((r,prior))
 failures=[];checks=0
 with (O/'Deliverables/CategoryExpansion/municipal_products_wide.csv').open(encoding='utf-8-sig',newline='') as f:
  reader=csv.DictReader(f)
  for row in reader:
   for r,old in matches:
    blob=groups[r['group']];i=blob['keys'].index(row['municipio_id']);actual=blob['variables'][r['indicator_id']][i];expected=int(row[old]);checks+=1
    if actual!=expected:failures.append(dict(indicator_id=r['indicator_id'],municipio_id=row['municipio_id'],source=old,actual=actual,expected=expected))
 for r,old in matches:r['equivalent_previous_indicator']=old
 animal_links={'bovino':'bovino_s6_p41b_species_total','ovino':'ovino_s6_p51b_species_total','porcino_granja':'porcinog_s6_p55b_species_total','porcino_corral':'porcinoc_s6_p57b_species_total','caprino':'caprino_s6_p60b_species_total','llamas':'llama_s6_p63b_species_total','alpacas':'alpaca_s6_p67b_species_total'}
 animal_discrepancies=[];animal_checks=0;blob=groups['livestock']
 for row in read(O/'Deliverables/Agro2013/animal_population_native_2013.csv'):
  i=blob['keys'].index(row['codmun'])
  for key,stem in animal_links.items():
   iid='cna13b_'+stem+'_sum';actual=blob['variables'][iid][i];expected=int(row[key]);animal_checks+=1
   if actual!=expected:animal_discrepancies.append(dict(indicator_id=iid,municipio_id=row['codmun'],actual=actual,expected=expected,source='animal_population_native_2013.csv:'+key,kind='absence_vs_published_zero' if actual is None and expected==0 else 'numeric_or_missing_difference',native_status=blob['status'][iid][i]))
 save(E/'previous_delivery_comparison.json',dict(created=now(),crop_aliases=len(matches),crop_comparisons=checks,crop_failures=failures,animal_comparisons=animal_checks,animal_discrepancies=animal_discrepancies,animal_absence_vs_published_zero=sum(x['kind']=='absence_vs_published_zero' for x in animal_discrepancies),animal_other_differences=sum(x['kind']!='absence_vs_published_zero' for x in animal_discrepancies),source='Previously supplied municipal aggregate distribution and preserved crop calculations; not an independent new survey',adjustments=False))
 if animal_discrepancies:outcsv(D/'animal_distribution_discrepancies.csv',animal_discrepancies)
 assert not failures,('Prior crop counts differ',len(failures))
 # Check explicitly labelled total/sex components only where all sums are complete.
 # Activity, age, species and remuneration contexts remain separate.
 component_specs=[('NROEMPL','S14_P124_1A',['S14_P124_1B','S14_P124_1C']),('GANADERIA','S6_P49T',['S6_P49M','S6_P49H']),('OVINO','S6_P51B',['S6_P51C','S6_P51D']),('PORCINOG','S6_P55B',['S6_P55C','S6_P55D','S6_P55E','S6_P55F']),('PORCINOC','S6_P57B',['S6_P57C','S6_P57D']),('CAPRINO','S6_P60B',['S6_P60C','S6_P60D'])]
 lookup={(r['source_variable'],r['context']):r for r in rs if r['operation']=='sum'}
 component_checks=0;component_skips=0;component_failures=[]
 for ent,total,parts in component_specs:
  for (field,context),r in lookup.items():
   if field!=ent+'.'+total:continue
   components=[lookup[(ent+'.'+f,context)] for f in parts];blob=groups[r['group']]
   for i,key in enumerate(blob['keys']):
    involved=[r,*components]
    if not all(blob['status'][s['indicator_id']][i]=='OBSERVADO' for s in involved):component_skips+=1;continue
    actual=blob['variables'][r['indicator_id']][i];expected=sum(blob['variables'][s['indicator_id']][i] for s in components);component_checks+=1
    if actual!=expected:component_failures.append(dict(indicator_id=r['indicator_id'],municipio_id=key,total=actual,sum_components=expected,context=context,components='|'.join(s['indicator_id'] for s in components)))
 save(E/'component_validation.json',dict(created=now(),status='FAIL' if component_failures else 'PASS',checks=component_checks,skipped_incomplete_or_absent=component_skips,failures=component_failures,rule='Only explicitly exhaustive total/sex components within the same activity, age and remuneration context, with all quantities observed. No adjustment.'))
 outcsv(D/'component_discrepancies.csv',component_failures,['indicator_id','municipio_id','total','sum_components','context','components'])
 for r in rs:r['component_discrepancies']=sum(x['indicator_id']==r['indicator_id'] for x in component_failures)
 save(D/'indicators.json',rs)
 # Keep the CSV dictionary aligned with equivalence metadata; preserve exact source decimal strings.
 dictionary=read(D/'variable_dictionary.csv');aliases={r['indicator_id']:old for r,old in matches}
 for r in dictionary:
  r['equivalent_previous_indicator']=aliases.get(r['indicator_id'],'')
  r['component_discrepancies']=sum(x['indicator_id']==r['indicator_id'] for x in component_failures)
 outcsv(D/'variable_dictionary.csv',dictionary)
 print('Prior crop checks',checks,'failures',len(failures),'animal checks',animal_checks,'discrepancies',len(animal_discrepancies))
 print('Component checks',component_checks,'discrepancies',len(component_failures),'incomplete or absent',component_skips)
if __name__=='__main__':run()
