"""Record the executing agent's completed inspection of the six rendered screenshots."""
from common import *

def run():
 evidence=json.loads((E/'browser_validation.json').read_text(encoding='utf-8'))
 assert evidence['status']=='PASS'
 shots=[dict(path=name,sha256=sha(E/name)) for name in evidence['screenshots']]
 save(E/'visual_review.json',dict(created=now(),status='PASS',method='Executing agent opened and visually inspected all six screenshots with view_image after the final browser test.',screenshots=shots,observations=['Preserved agricultural hero v3 is legible on desktop and mobile; no image regeneration.', 'Desktop controls use two rows with a wider indicator selector; mobile content stays within viewport.', 'Municipal map, full top 10 and formatted thousands/two-decimal values are legible.', 'No-data explanation is visible below the selected municipality after correcting the inherited count-view CSS.', 'Spanish accents render correctly. Labels, units, season and limits remain visible.'],limitation='Visual review covers representative desktop/mobile states; browser checks cover all 13 module values and tested controls.'))
 evidence['visual_review']='PASS; see visual_review.json';save(E/'browser_validation.json',evidence)
 print('Recorded completed visual inspection; no human acceptance implied.')

if __name__=='__main__':run()
