"""Explicit source-field disposition; no guessed binary labels or summed identifiers."""
from common import *
from collections import defaultdict
SCHEMA=json.loads((BASE/'schema.json').read_text(encoding='utf-8'))
V={v['variable_id']:v for v in SCHEMA['variables']}
C=defaultdict(list)
for c in SCHEMA['categories']:C[c['variable_id']].append(c)
GROUPS={
 'structure':('Estructura y tenencia de la UPA',['UPA','OTROSDAT']),
 'agriculture':('Producción y calendario agrícola',['CULTIVOS','CULTINV','CULTVER','CULTSEM','CULTPAS','CULTFOR','CULTOTR']),
 'plants':('Frutales dispersos y medicinales',['CULTFRU','CULTMED']),
 'practices':('Prácticas y agricultura orgánica',['PRACAGRI','CULTORG']),
 'livestock':('Ganadería, leche y apicultura',['GANADERIA','BOVINO','OVINO','PORCINOG','PORCINOC','CAPRINO','LLAMA','ALPACA','OTRESP','AVESG','AVESC']),
 'health':('Sanidad animal',['SANIDAD']),
 'water':('Riego y fuentes de agua',['FUENTEAGUA']),
 'forest':('Bosques y productos forestales',['BOSQMONT','ESPMADER','ESPNOMADER']),
 'fishing':('Caza, pesca y cría acuática',['CAZAPEZCA','ESPCAZA','ESPPESCA','ESPCRIA']),
 'workforce':('Trabajo y composición familiar',['PERSONAL','NROEMPL','COMPFAM']),
 'energy':('Energía y uso de maquinaria',['ENERGIA']),
 'infrastructure':('Infraestructura y equipamiento',['MAQAGRI','INFRAGRI','EQUIPAVE','INFRGAN','EQUIGAN','CONSTRUCCION','MAQUINARIA']),
 'services':('Asistencia, crédito y seguros',['APOCRED','ASIST','SEGURO'])}
ENTITY_GROUP={e:g for g,(_,es) in GROUPS.items() for e in es}
# Primary category provides meaningful splits of physical quantities.
KEYS=dict(CULTINV='S4_P23_2',CULTVER='S4_P24_2',CULTSEM='S4_P25_A',CULTPAS='S4_P26_A',CULTFOR='S4_P27_A',CULTOTR='S4_P27_D',CULTFRU='S4_P29_1A',CULTMED='S4_P30_1',CULTORG='S5_P37_1A',MAQAGRI='S5_P39A',INFRAGRI='S5_38',BOVINO='S6_P41A',OVINO='S6_P51A',PORCINOG='S6_P55A',PORCINOC='S6_P57A',CAPRINO='S6_P60A',LLAMA='S6_P63A',ALPACA='S6_P67A',OTRESP='S6_P70_1',AVESG='S6_P73_1',AVESC='S6_P76_2',EQUIPAVE='S6_P74A',INFRGAN='S7_P86',EQUIGAN='S7_P87_1A',ESPMADER='COD92_1',ESPNOMADER='S9_F96',ESPCAZA='S10_P98A',ESPPESCA='S10_P101A',ESPCRIA='S10_P104B',CONSTRUCCION='S12_P115',MAQUINARIA='CATEGORIA',SEGURO='COD114_2')
QUANT={}
def quantities(entity,fields,unit):
 for f in fields.split():QUANT[entity+'.'+f]=unit
quantities('UPA','S3_P20A','parcelas')
quantities('UPA','S3_P20B S3_P21_1 S3_P21_2 S3_P21_3 S3_P21_4 S3_P21_5','ha')
quantities('CULTINV','S4_P23_6','qq')
quantities('CULTVER','S4_P24_8','qq')
quantities('CULTFRU','S4_P29D','plantas')
quantities('GANADERIA','S6_P42 S6_P49T S6_P49M S6_P49H','cabezas')
quantities('GANADERIA','S6_P44','litros del día anterior')
quantities('GANADERIA','S6_P80','cajas de colmenas')
quantities('GANADERIA','S6_P81A','unidad de miel separada por código')
for ent,fields in {'BOVINO':'S6_P41B S6_P41C S6_P41D','OVINO':'S6_P51B S6_P51C S6_P51D','PORCINOG':'S6_P55B S6_P55C S6_P55D S6_P55E S6_P55F','PORCINOC':'S6_P57B S6_P57C S6_P57D','CAPRINO':'S6_P60B S6_P60C S6_P60D','LLAMA':'S6_P63B S6_P63C S6_P63D S6_P63E','ALPACA':'S6_P67B S6_P67C S6_P67D S6_P67E','OTRESP':'S6_P70_5','AVESG':'S6_P73_2','AVESC':'S6_P76_4'}.items():quantities(ent,fields,'cabezas')
for ent,fields in {'MAQAGRI':'S5_P39B','INFRAGRI':'S5_38_1A','EQUIPAVE':'S6_P74B','INFRGAN':'S7_P86A','EQUIGAN':'S7_P87_2C','MAQUINARIA':'S12_P116A'}.items():quantities(ent,fields,'unidades')
quantities('CONSTRUCCION','S12_P115A','según categoría')
quantities('NROEMPL','S14_P124_1A S14_P124_1B S14_P124_1C','trabajadores declarados por UPA')
quantities('ESPNOMADER','SF_96A CONSUMO_DE_HOGAR_QQ','qq')
ALREADY={'CULTINV.S4_P23_3','CULTVER.S4_P24_4','CULTVER.S4_P24_4_1','CULTSEM.S4_P25_B','CULTPAS.S4_P26_B','CULTFOR.S4_P27_B','CULTOTR.S4_P27_E'}
PARCEL_IDS={'CULTINV.S4_P23_1','CULTVER.S4_P24_1'}
CALENDAR_FIELDS={f for f,v in V.items() if v['label'].strip().lower() in ['primer año','último año','año de plantación']}
NUMERIC_FREQUENCIES=CALENDAR_FIELDS|{'COMPFAM.S15_P129_2','COMPFAM.S15_P129_4','GANADERIA.S6_P43'}
def disposition(v):
 f=v['variable_id'];e=v['entity']
 if e not in ENTITY_GROUP or f in ['UPA.UPA','UPA.REDCODEC']:return 'geographic_or_identifier'
 if f in PARCEL_IDS:return 'parcel_reference_not_additive'
 if e=='OTROSDAT' and v['type_effective']=='STRING':return 'free_text_excluded'
 if f in ALREADY:return 'preserved_previous_area_series'
 if f in QUANT:return 'quantity'
 return 'frequency'
def valid(f):
 v=V[f];rr=json.loads(v['ranges_json']);assert rr,f
 intervals=' OR '.join(f'({f} >= {r["min"]} AND {f} <= {r["max"]})' for r in rr)
 return '('+intervals+') AND NOT MISSING('+f+') AND NOT NOTAPPLICABLE('+f+')'
def literal(f,code):
 if V[f]['type_effective']=='STRING':return '"'+str(code).replace('"','')+'"'
 return str(int(str(code).replace(' ','')))
def comparison(f,code):
 if code=='':return f'LENGTH(TRIM({f})) = 0'
 left=f'TRIM({f})' if V[f]['type_effective']=='STRING' and len(str(code))!=int(V[f]['dataset_size']) else f
 return left+' = '+literal(f,code)
def period(f):
 if f.startswith('CULTINV.'):return 'invierno 2012'
 if f.startswith('CULTVER.'):return 'verano 2012–2013'
 if f in ['GANADERIA.S6_P42','GANADERIA.S6_P44']:return 'día anterior a la entrevista'
 if f.startswith(('APOCRED.S11_P106','APOCRED.S11_P108','ASIST.')):return 'últimos tres años, según pregunta'
 if f.startswith('GANADERIA.S6_P81'):return 'últimos doce meses'
 return 'CNA2013; referencia específica conservada en pregunta fuente'
def run():
 rows=[]
 for v in V.values():rows.append(dict(variable_id=v['variable_id'],entity=v['entity'],label=v['label'],type=v['type_effective'],disposition=disposition(v),group=ENTITY_GROUP.get(v['entity'],'geography'),unit=QUANT.get(v['variable_id'],''),range=v['ranges_json'],missing=v['missing'],not_applicable=v['not_applicable'],status='PLANNED' if disposition(v) in ['frequency','quantity'] else 'DOCUMENTED'))
 outcsv(D/'field_coverage.csv',rows)
 save(E/'schema_reference.json',dict(source=str(BASE/'schema.json'),sha256=sha(BASE/'schema.json'),entities=len(SCHEMA['entities']),variables=len(V)))
 from collections import Counter
 print(dict(Counter(r['disposition'] for r in rows)))
if __name__=='__main__':run()
