"""Repair omitted hash metadata only after comparing recipes to the executed definitions."""
from common import *

def run():
 rs=json.loads((D/'indicators.json').read_text(encoding='utf-8'));fixed={};audit=[]
 for r in rs:
  if r.get('reproduction_sha256'):continue
  p=D/'Recipes'/r['reproduction_program'];out=E/'RecipeRuns'/(r['indicator_id']+'.csv')
  expected=f'RUNDEF individual\n DICTIONARY "{W / "CNA2013.dicx"}"\n SELECTION ALL\n NOWEIGHT\n\n'+r['prerequisites']+'\n'+r['redatam_code']+'\nTABLE RESULTA AS AREALIST OF MUNIC, MUNIC.'+r['redatam_column']+f'\n OUTPUTFILE CSV "{out}" UTF8\n'
  assert p.read_text(encoding='utf-8').strip()==expected.strip(),p
  batch=E/'Programs'/r['execution_program'];assert sha(batch)==r['program_sha256']
  body=batch.read_text(encoding='utf-8');assert r['redatam_code'] in body
  if r['prerequisites']:assert r['prerequisites'] in body
  receipt=json.loads((E/'Results'/(batch.stem+'_run.json')).read_text(encoding='utf-8'))
  assert receipt['export_complete_stable'] and receipt['program_sha256']==sha(batch)
  digest=sha(p);r['reproduction_sha256']=digest;fixed[r['indicator_id']]=digest
  audit.append(dict(indicator_id=r['indicator_id'],recipe=p.name,sha256=digest,exact_generated_recipe_match=True,executed_batch_definition_match=True))
 assert len(fixed)==72,len(fixed)
 save(E/'recipe_hash_metadata_repair.json',dict(created=now(),status='PASS',cause='Pig correction loaded pre-hash plan metadata for unchanged recipes. Those individual files were preserved, but 72 hashes were omitted from the canonical metadata after goat correction.',scope='Metadata-only restoration after exact recipe-text and executed-batch validation; no program, data or HTML value changed.',checks=audit))
 save(D/'indicators.json',rs)
 canonical=json.loads((E/'recipes.json').read_text(encoding='utf-8'))
 for r in canonical:
  if r['indicator_id'] in fixed:r['reproduction_sha256']=fixed[r['indicator_id']]
 save(E/'recipes.json',canonical)
 table=read(D/'variable_dictionary.csv')
 for r in table:
  if r['indicator_id'] in fixed:r['reproduction_sha256']=fixed[r['indicator_id']]
 outcsv(D/'variable_dictionary.csv',table)
 print('Restored 72 recipe hashes after exact content validation; no data/program changes.')

if __name__=='__main__':run()
