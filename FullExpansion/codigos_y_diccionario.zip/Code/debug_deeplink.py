from common import *
from playwright.sync_api import sync_playwright
rs=json.loads((D/'indicators.json').read_text(encoding='utf-8'))
r=next(r for r in rs if r['operation']=='sum' and r['group']=='agriculture')
with sync_playwright() as pw:
 b=pw.chromium.launch(channel='msedge',headless=True);p=b.new_page();errors=[]
 p.on('pageerror',lambda e:errors.append(str(e)))
 p.goto((D/'catalogo.html').as_uri()+'#'+r['indicator_id'])
 link=p.get_by_role('link',name='Abrir en el mapa');print('expected',r['indicator_id'],'href',link.get_attribute('href'),flush=True)
 link.click();p.wait_for_load_state('load');p.evaluate('window.productsReady')
 print(p.evaluate('({url:location.href,selected:$("#animal").value,requested:fullRequested,requestedMeta:variableById.get(fullRequested),topic:$("#topic").value})'),flush=True);print('errors',errors)
 b.close()
