"""Documented native string concatenation prevents numeric formatting of code values."""
from specification import *
def run():
 fs=[f for f,v in V.items() if disposition(v)=='frequency' and v['type_effective']=='STRING'];queue=[]
 for start in range(0,len(fs),12):
  part=fs[start:start+12];name=f'rawstrings_{start//12:02d}';body=[];extras=[]
  for i,f in enumerate(part):
   ent=V[f]['entity'];raw=f'{ent}.RAW{i}';stem=E/'Results'/f'{name}_{i}'
   body += [f'DEFINE {raw} AS "X" + TRIM({f}) TYPE STRING SIZE {int(V[f]["dataset_size"])+1}',f'TABLE F{i} AS FREQUENCY OF {raw}\n OUTPUTFILE HTML "{stem}.html" UTF8'];extras.append(str(stem)+f'_F{i}.html')
  dest=E/'Results'/f'{name}.csv';body+=['DEFINE MUNIC.NUP AS COUNT UPA TYPE INTEGER',f'TABLE ENDLIST AS AREALIST OF MUNIC, MUNIC.NUP\n OUTPUTFILE CSV "{dest}" UTF8']
  p=program(name,'\n'.join(body));save(E/'Plans'/f'{name}.json',dict(name=name,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(dest),rows=339,columns=2)],extra_files=extras,fields=part));queue.append(name)
 save(E/'rawstrings_queue.json',queue)
 print(len(fs),'fields',len(queue),'batches')
if __name__=='__main__':run()
