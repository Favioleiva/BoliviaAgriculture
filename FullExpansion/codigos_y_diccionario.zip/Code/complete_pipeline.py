"""Wait for the bounded native queue, then validate and build the local delivery."""
from common import *
import subprocess,sys,time

def run():
 pending=json.loads((E/'paired_queue.json').read_text(encoding='utf-8'))
 while True:
  complete=[]
  for name in pending:
   path=E/'Results'/(name+'_run.json')
   if path.exists():
    r=json.loads(path.read_text(encoding='utf-8'));assert r['export_complete_stable'],name
    complete.append(name)
  progress=json.loads((E/'paired_progress.json').read_text(encoding='utf-8'))
  assert all(x['complete'] for x in progress['completed']),progress
  if len(complete)==len(pending) and len(progress['completed'])==len(pending):break
  save(E/'pipeline_checkpoint.json',dict(created=now(),state='WAITING_FOR_NATIVE_QUEUE',complete=len(complete),total=len(pending)))
  time.sleep(20)
 # The original queue has stopped all its own engines before receipt completion.
 steps=[['run_queue.py',str(E/'goat_correction_queue.json')],['run_queue.py',str(E/'coverage_queue.json')],['analyze.py'],['compare_existing.py'],['build_catalogue.py'],['build_dashboard.py'],['verify_dashboard.py']]
 results=[]
 for args in steps:
  name=args[0];save(E/'pipeline_checkpoint.json',dict(created=now(),state='RUNNING',step=name,completed=results))
  with (E/(name.replace('.py','')+'_execution.log')).open('w',encoding='utf-8') as log:
   process=subprocess.run([sys.executable,'-B',str(E/'Code'/name),*args[1:]],cwd=R,stdout=log,stderr=subprocess.STDOUT)
  results.append(dict(step=name,exit_code=process.returncode));assert process.returncode==0,(name,'See saved execution log')
 save(E/'pipeline_checkpoint.json',dict(created=now(),state='READY_FOR_VISUAL_REVIEW_AND_PACKAGING',completed=results))
 print('Validated pipeline complete; inspect screenshots, then finalize delivery. No automatic human acceptance.')

if __name__=='__main__':run()
