"""Early exact checks of completed batches; never treats an incomplete file as final."""
from common import *
from decimal import Decimal

def run():
 names=json.loads((E/'execution_queue.json').read_text(encoding='utf-8'));completed=[];failures=[];reals=[];checks=0
 for name in names:
  if not name.endswith('_m'):continue
  dname=name[:-1]+'d';paths=[E/'Results'/(x+'_run.json') for x in [name,dname]]
  if not all(p.exists() for p in paths):continue
  receipts=[json.loads(p.read_text(encoding='utf-8')) for p in paths]
  if not all(r['export_complete_stable'] for r in receipts):continue
  plan=json.loads((E/'Plans'/(name+'.json')).read_text(encoding='utf-8'));m=read(E/'Results'/(name+'.csv'),';');d=read(E/'Results'/(dname+'.csv'),';')
  assert len(m)==len({r['REDCODE'] for r in m})==339 and len(d)==9
  for r in plan['recipes']:
   col=r['redatam_column'];vals={x['REDCODE']:Decimal(x[col]) for x in m}
   if r['expected_national'] is not None:
    checks+=1;actual=sum(vals.values());expected=Decimal(r['expected_national'])
    if actual!=expected:failures.append(dict(program=name,indicator=r['indicator_id'],test='national_frequency',actual=str(actual),expected=str(expected)))
   for row in d:
    part=[v for k,v in vals.items() if k.startswith(row['REDCODE'])];actual=sum(part);expected=Decimal(row[col]);checks+=1
    tolerance=Decimal(0) if r['integer_expected'] else Decimal('0.0000005')*(len(part)+1)
    if abs(actual-expected)>tolerance:
     (failures if r['integer_expected'] else reals).append(dict(program=name,indicator=r['indicator_id'],test='department_reconciliation',department=row['REDCODE'],actual=str(actual),expected=str(expected)))
  completed.append(name)
 save(E/'progress_validation.json',dict(created=now(),completed_pairs=len(completed),checks=checks,integer_failures=failures,real_discrepancies=reals,complete=False))
 print('Audited pairs:',len(completed),'checks:',checks,'integer failures:',len(failures),'real discrepancies:',len(reals))
 if failures:print(json.dumps(failures[:10],ensure_ascii=True))
if __name__=='__main__':run()
