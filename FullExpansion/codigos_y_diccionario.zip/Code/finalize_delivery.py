"""Package verified outputs and record delivery, never human acceptance or publication."""
from common import *
import zipfile,re,platform,subprocess,importlib.metadata

def run():
 stamp=now();state='DELIVERED — AWAITING HUMAN APPROVAL'
 validation=json.loads((E/'validation.json').read_text(encoding='utf-8'))
 browser=json.loads((E/'browser_validation.json').read_text(encoding='utf-8'))
 review=json.loads((E/'visual_review.json').read_text(encoding='utf-8'))
 summary=json.loads((E/'export_summary.json').read_text(encoding='utf-8'))
 comparison=json.loads((E/'previous_delivery_comparison.json').read_text(encoding='utf-8'))
 components=json.loads((E/'component_validation.json').read_text(encoding='utf-8'))
 assert validation['integrity_and_counts_status']=='PASS'
 assert browser['status']=='PASS' and review['status']=='PASS'
 assert not comparison['crop_failures']
 rs=json.loads((D/'indicators.json').read_text(encoding='utf-8'))
 queue=json.loads((E/'queue.json').read_text(encoding='utf-8'))
 receipts=[json.loads((E/'Results'/f'{name}_run.json').read_text(encoding='utf-8')) for name in queue]
 assert all(r['export_complete_stable'] for r in receipts)
 for filename,status in [('pig_correction.json','EXECUTED_VALIDATED; superseded by v3 preserving corrected pig definitions'),('goat_correction.json','EXECUTED_VALIDATED')]:
  record=json.loads((E/filename).read_text(encoding='utf-8'));record.update(status=status,validated=stamp);save(E/filename,record)
 save(E/'pipeline_checkpoint.json',dict(created=stamp,state='DELIVERED_PENDING_HUMAN_ACCEPTANCE',last_success='Native counts, prior comparison, component checks, all module browser values and visual review complete',normal_engine_exit_verified=False,remaining_limitations='28 real reconciliation discrepancies; 12 fields retain explicitly unclassified records; historical geography equivalence unverified'))
 # Verify the immutable original and copied database again after processing.
 source=json.loads((BASE/'source_manifest.json').read_text(encoding='utf-8'))['files']
 for f in source:
  assert sha(R/f['path'])==f['sha256'],f['path']
  assert sha(W/f['filename'])==f['sha256'],f['filename']
 save(E/'source_final_verification.json',dict(created=stamp,status='PASS',original_files=len(source),working_copy_files=len(source),method='Full SHA256 comparison to preserved source manifest; no source mutation'))
 environment=dict(created=stamp,python=platform.python_version(),platform=platform.platform(),dependencies={name:importlib.metadata.version(name) for name in ['beautifulsoup4','playwright']},engine=str(EXE),engine_sha256=sha(EXE),engine_version='7.3.4.2',maximum_owned_engines=2,timeout_per_program_seconds=1800,normal_engine_exit='Not verified; own PID terminated only after stable complete exports')
 save(E/'environment.json',environment)
 recipe_hashes={}
 for r in rs:
  p=D/'Recipes'/r['reproduction_program'];digest=sha(p);assert digest==r['reproduction_sha256'],p
  recipe_hashes[p.name]=digest
 programs={r['execution_program']:r['program_sha256'] for r in rs}
 for name,digest in programs.items():assert sha(E/'Programs'/name)==sha(D/'Programs'/name)==digest,name
 save(E/'recipe_verification.json',dict(created=stamp,status='PASS',individual_recipes=len(recipe_hashes),executed_programs=len(programs),individual_recipes_run_separately=False,method='Executed batch programs and every recipe verified against generation hashes'))
 equivalent=sum(bool(r.get('equivalent_previous_indicator')) for r in rs)
 narrative=(f"Adenda04-B: {len(rs):,} definiciones municipales ({summary['analytical']:,} analíticas y {summary['diagnostic']:,} diagnósticas), "
  f"en 13 módulos y 339 municipios. Incluyen {equivalent:,} equivalencias explícitas con conteos de productos anteriores; no son todas variables nuevas independientes. "
  f"Inventario completo: 54 entidades, 329 campos. Se preservan las 86 variables y los 611 códigos anteriores. "
  f"Controles de integridad/conteos PASS; {validation['checks']:,} comprobaciones internas. "
  f"Conciliación global {validation['scientific_status']}: {validation['real_reconciliation_failures']} discrepancias en cantidades reales, sin ajustes ni relajación de tolerancias. "
  f"Comparación previa: {comparison['crop_comparisons']:,} conteos de cultivos, sin diferencias; {comparison['animal_comparisons']:,} valores animales, {len(comparison['animal_discrepancies'])} diferencias documentadas. "
  f"De estas últimas, {comparison['animal_absence_vs_published_zero']} distinguen ausencia de cantidad válida frente a cero publicado, y {comparison['animal_other_differences']} son otras diferencias. "
  f"Totales frente a componentes: {components['checks']:,} controles, {len(components['failures'])} diferencias. "
  "Las 47 discrepancias anteriores de superficies permanecen en su evidencia histórica. No existe información de precios ni importes monetarios por destino en los campos auditados.")
 execution=(narrative+"\n\nMotor oficial REDATAM7 sobre copia verificada, dos procesos propios como máximo. "
  "Las tablas MUNIC y DEPTO se calcularon directamente en cada nivel; las definiciones intermedias de pertenencia a UPA se comparten dentro del lote. "
  "Frecuencias nacionales independientes; códigos STRING exactos recuperados mediante prefijo alfanumérico, sin inferir ceros iniciales. "
  "Los intentos previos, incluso los fallidos, permanecen guardados. Las recetas individuales contienen dependencias, pero se validó la ejecución de lotes y no miles de ejecuciones individuales. "
  "Registros, UPA únicas y cantidades físicas conservan unidades distintas. Las filas porcinas 01 coinciden exactamente con la suma de grupos 02/03/04 en ocho campos y 339 municipios; los totales por especie excluyen la fila superpuesta, con programas v2 y comparaciones conservadas. Ausencia de cantidades válidas produce nulo; las sumas parciales quedan señaladas. "
  "Crudo significa agregado de la base procesada disponible: el INE documenta, por ejemplo, imputación de blancos a cero en aves de granja. No se reconstruyen esas respuestas originales. No se exportaron microregistros ni se publicaron datos. Inputs/C01/C02 y la planificación congelada permanecen intactos. "
  "Todos los originales y la copia de trabajo coinciden por SHA256 con el manifiesto fuente.\n\n"
  "Reproducción: Evidence/FullExpansion/Code/run_pairs.py reusa recibos completos comprobados; no sobrescribir salidas incompletas, crear un reintento versionado. "
  "Secuencia posterior: analyze.py → compare_existing.py → build_catalogue.py → build_dashboard.py → verify_dashboard.py → revisión visual → finalize_delivery.py. "
  "Los generadores iniciales son de una sola ejecución sobre directorios nuevos: no ejecutarlos sobre la entrega completa. "
  "Planes/recibos/programas/recetas/hashes permiten reanudar sin reconstruir el estado desde el chat.")
 checks=(narrative+"\n\nPASS: 339 claves municipales y 9 departamentales; conteos enteros y frecuencias nacionales; particiones y límites de UPA; "
  "conservación exacta de datos anteriores; todos los valores de los 13 módulos contrastados en navegador; top 10, pocos resultados, nulos y sumas parciales; "
  "selección municipal, navegación por pregunta, búsqueda, ES/EN, descargas locales, escritorio/móvil y hero v3. "
  "PASS: originales/copia/recetas/programas y ZIP por hashes/CRC. "
  "LIMITACIÓN: discrepancias reales documentadas, normalidad de salida del motor no comprobada, comparación externa parcial, "
  "geometría de 2015 enlazada operativamente a claves censales de 2013. No se garantiza equivalencia histórica de límites. Las sumas siguen la jerarquía municipal de la UPA y no prueban ubicación física de cada parcela dentro del polígono. "
  "Los controles técnicos no constituyen aceptación humana ni una certificación estadística global PASS.")
 closure=("PENDING HUMAN ACCEPTANCE.\n\n"+narrative+"\n\nTrabajo autorizado implementado y entregado con límites explícitos. "
  "No se congela C04 ni se renombra el contrato a _approved. No hay motores propios pendientes. "
  "Las decisiones de aceptar las discrepancias o autorizar investigación adicional corresponden al supervisor.")
 links="\n\n[Visor](Deliverables/Agro2013/index.html), [catálogo](Deliverables/FullExpansion/catalogo.html), [método](Deliverables/FullExpansion/README.html), [controles](Evidence/FullExpansion/validation.json), [navegador](Evidence/FullExpansion/browser_validation.json), [código](Deliverables/FullExpansion/codigos_y_diccionario.zip).\n\n"
 coverage_note='\n\nCobertura: 12 campos tienen registros que la frecuencia nativa no clasifica. Los 26 diagnósticos añadidos contabilizan esos registros y UPA afectadas; la partición incluye este residual explícito. No se recuperó su código ni causa y no se les atribuye significado sustantivo. Ampliar rangos temporales no recuperó códigos; la sintaxis de igualdad a valores especiales no produjo una salida válida en esta instalación. Pruebas e intentos conservados. Los conteos residuales se contrastaron con los 4.068 déficits municipales originales, incluyendo ceros. En caprinos, las filas no clasificadas duplicaban exactamente la suma de grupos 2/3/4 en tres cantidades y 339 municipios; programas v3 usan únicamente los grupos etiquetados, preservando la corrección porcina y los intentos anteriores.\n'
 for name,body in [('90_EXECUTION_REPORT.md',execution),('91_VALIDATION_REPORT.md',checks),('99_CLOSURE_REPORT.md',closure)]:
  prior=(E/'History'/O.relative_to(R)/name).read_text(encoding='utf-8')
  write(O/name,'# Ampliación integral CNA2013 — '+state+'\n\n'+body+coverage_note+links+'## Entrega anterior preservada\n\n'+prior)
 contract=R/'Contracts/Contract_04.txt';write(contract,re.sub(r'^Estado:.*$','Estado: '+state,contract.read_text(encoding='utf-8'),count=1,flags=re.M))
 register=R/'Contracts/CONTRACT_REGISTER.md';oldregister=register.read_text(encoding='utf-8')
 write(register,'## C04 — Adenda04-B entregada, pendiente de aceptación humana\n\n'+narrative+'\n\n'+oldregister)
 checkpoint=dict(updated=stamp,state=state,last_success='Complete native extraction, field coverage, verified municipal modules, browser and visual review, code archive',human_acceptance='PENDING',publication=False,active_processes=[],scientific_status=validation['scientific_status'],reconciliation_failures=validation['real_reconciliation_failures'],previous_area_reconciliation_failures=47,restart_command='python -B Outputs/Contract_04/Evidence/FullExpansion/Code/verify_dashboard.py',remaining_issues='Documented real reconciliation differences, partial external checks, unverified normal engine exit and 2013/2015 boundary equivalence')
 save(E/'checkpoint.json',checkpoint);save(O/'Evidence/checkpoint.json',checkpoint)
 save(E/'contract_provenance.json',dict(created=stamp,state=state,contract_path=str(contract.relative_to(R)),contract_sha256=sha(contract),authorization='ok, entonces a expandir todo',adendum='04-B',human_acceptance='PENDING',frozen=False,publication=False))
 # Portable archive of code and aggregate evidence, never database microrecords.
 bundle=D/'codigos_y_diccionario.zip';temp=bundle.with_suffix('.tmp')
 sources=[]
 for folder in ['Code','Plans']:
  sources += [(p,folder+'/'+p.name) for p in sorted((E/folder).glob('*')) if p.is_file()]
 sources += [(D/'Recipes'/name,'Recipes/'+name) for name in recipe_hashes]
 sources += [(D/'Programs'/name,'Programs/'+name) for name in programs]
 sources += [(p,'RawResults/'+p.name) for p in sorted((D/'RawResults').glob('*.csv'))]
 sources += [(p,'Modules/'+p.name) for p in sorted((D/'Modules').glob('*.csv'))]
 for name in ['variable_dictionary.csv','field_coverage.csv','validation_discrepancies.csv','component_discrepancies.csv','indicators.json','README.html']:
  sources.append((D/name,name))
 for name in ['queue.json','paired_queue.json','observed_domains.json','unit_evidence.json','validation.json','component_validation.json','previous_delivery_comparison.json','browser_validation.json','visual_review.json','recipe_verification.json','environment.json','source_final_verification.json','string_code_recovery.json','contract_provenance.json','pig_total_overlap_validation.json','pig_correction.json','numeric_frequency_semantics.json','source_processing_notes.json']:
  sources.append((E/name,'Evidence/'+name))
 for name in ['schema.json','source_manifest.json']:sources.append((BASE/name,'SourceMetadata/'+name))
 for name in ['goat_total_overlap_validation.json','goat_correction.json','coverage_resolution.json','coverage_probe_parsed.json','coverage_probe_syntax.json','goat_correction_queue.json','coverage_queue.json','coverage_retry.json','recipe_hash_metadata_repair.json']:
  sources.append((E/name,'Evidence/'+name))
 sources += [(p,'AuditPrograms/'+p.name) for p in sorted((E/'Programs').glob('*.spc'))]
 sources += [(p,'CoverageAudit/'+p.name) for p in sorted((E/'Results').glob('coverage*')) if p.is_file()]
 sources.append((E/'source_provenance_normalization.json','Evidence/source_provenance_normalization.json'))
 for relative in ['index.html','assets/app.js','assets/style.css']:
  sources.append((E/'History'/O.relative_to(R)/'Deliverables/Agro2013'/relative,'Baseline/Agro2013/'+relative))
 sources += [(E/'Results'/f'{name}_run.json','Receipts/'+f'{name}_run.json') for name in queue]
 with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
  for path,name in sources:z.write(path,name)
  z.writestr('REPRODUCCION.txt','Programas ejecutados y recetas individuales CNA2013. No incluye microdatos.\nRestaurar bajo Outputs/Contract_04 y conservar la estructura del proyecto Bolivia. Los programas SPC incluyen rutas absolutas del proyecto original: ajustar rutas de diccionario y salidas en una copia para otro equipo, documentando cambios. REDATAM7 7.3.4.2.\nNo ejecutar generadores de una sola pasada sobre salidas existentes. Consultar planes, hashes y recibos. El código Python está en Evidence/FullExpansion/Code; los módulos CSV en Deliverables/FullExpansion/Modules.\nRecetas individuales no ejecutadas una por una: se ejecutaron y validaron sus lotes. Controles internos no sustituyen aceptación humana.\n')
 with zipfile.ZipFile(temp) as z:
  assert z.testzip() is None
  for path,name in sources:assert hashlib.sha256(z.read(name)).hexdigest()==sha(path),name
 os.replace(temp,bundle)
 save(E/'bundle_verification.json',dict(created=now(),status='PASS',archive_sha256=sha(bundle),files=len(sources)+1,all_entries_match_sources=True,contains_microdata=False))
 def entry(p,root):return dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
 codepath=O/'Evidence/code_manifest.json';oldcode=json.loads(codepath.read_text(encoding='utf-8'))
 paths={R/f['path'] for f in oldcode['files']}|{p for p in (E/'Code').glob('*') if p.is_file()}
 save(codepath,dict(created=stamp,state=state,files=[entry(p,R) for p in sorted(paths)]))
 save(E/'delivery_manifest.json',dict(created=stamp,state=state,frozen=False,files=[entry(p,O) for p in sorted(D.rglob('*')) if p.is_file()]+[entry(p,O) for p in [O/'Deliverables/Agro2013/index.html',O/'Deliverables/Agro2013/assets/app.js',O/'Deliverables/Agro2013/assets/style.css']]))
 manifest=O/'Evidence/artifact_manifest.json';old={f['path']:f for f in json.loads(manifest.read_text(encoding='utf-8'))['files']}
 changed={'90_EXECUTION_REPORT.md','91_VALIDATION_REPORT.md','99_CLOSURE_REPORT.md','Evidence/checkpoint.json','Evidence/code_manifest.json','Deliverables/Agro2013/index.html','Deliverables/Agro2013/assets/app.js','Deliverables/Agro2013/assets/style.css'}
 files=[]
 for p in sorted(O.rglob('*')):
  if not p.is_file() or p==manifest or '__pycache__' in p.parts:continue
  key=p.relative_to(O).as_posix()
  if key in changed or key not in old or key.startswith(('Evidence/FullExpansion/','Deliverables/FullExpansion/','Deliverables/Agro2013/assets/full/')):files.append(entry(p,O))
  else:
   assert p.stat().st_size==old[key]['bytes'],key;files.append(old[key])
 save(manifest,dict(created=now(),state=state,frozen=False,files=files,exclusion='self and __pycache__',refresh='All new/changed expansion artifacts hashed; prior unchanged artifacts retained with size checks; immutable source fully rehashed'))
 print(narrative)
 print('Delivery documented, archive verified, PENDING HUMAN ACCEPTANCE')

if __name__=='__main__':run()
