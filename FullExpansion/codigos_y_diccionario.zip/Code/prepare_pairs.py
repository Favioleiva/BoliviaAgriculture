"""Combine independently defined municipal/department tables in one native job."""
from common import *
import shutil
def run():
 allnames=json.loads((E/'queue.json').read_text(encoding='utf-8'));queue=[];mapping={}
 for mname in allnames:
  if not mname.endswith('_m'):continue
  dname=mname[:-1]+'d';sources=[mname,dname]
  if all((E/'Results'/(n+'_run.json')).exists() and json.loads((E/'Results'/(n+'_run.json')).read_text())['export_complete_stable'] for n in sources):continue
  assert not any((E/'Results'/(n+'.csv')).exists() for n in sources),('Preserve partial output with versioned retry',sources)
  name='pair_'+mname[:-2];parts=[];outputs=[]
  for src in sources:
   cfg=json.loads((E/'Plans'/(src+'.json')).read_text(encoding='utf-8'));body=(E/'Programs'/(src+'.spc')).read_text(encoding='utf-8').split('NOWEIGHT',1)[1].strip()
   if src.endswith('_d'):body='\n'.join(line for line in body.splitlines() if not line.startswith('DEFINE UPA.'))
   body=body.replace('TABLE RESULTA AS','TABLE '+('MRES' if src.endswith('_m') else 'DRES')+' AS');parts.append(body);outputs+=cfg['outputs'];mapping[src]=name
  p=program(name,'\n'.join(parts));save(E/'Plans'/(name+'.json'),dict(name=name,program_sha256=sha(p),timeout_seconds=1800,outputs=outputs,paired_sources=sources));shutil.copy2(p,D/'Programs'/p.name);queue.append(name)
 recipes=json.loads((E/'recipes.json').read_text(encoding='utf-8'));hashes={n:sha(E/'Programs'/(n+'.spc')) for n in set(mapping.values())}
 for r in recipes:
  src=r['execution_program'][:-4]
  if src in mapping:r.update(execution_program=mapping[src]+'.spc',program_sha256=hashes[mapping[src]])
 save(E/'recipes.json',recipes)
 priority=['water','workforce','energy','health','services','structure','livestock','infrastructure','plants','practices','agriculture','forest','fishing']
 queue.sort(key=lambda n:(next((i for i,g in enumerate(priority) if '_'+g+'_' in n),len(priority)),n))
 save(E/'paired_queue.json',queue);save(E/'execution_queue.json',allnames)
 print('Prepared',len(queue),'paired jobs; prior completed outputs reused')
if __name__=='__main__':run()
