"""National aggregate HTML frequency discovery, using the official engine."""
from specification import *
import shutil
def run():
 targets=[v for v in V.values() if disposition(v)=='frequency'];queue=[]
 for start in range(0,len(targets),24):
  name=f'discover_{start//24:02d}';part=targets[start:start+24];body=[];extra=[]
  for i,v in enumerate(part):
   stem=E/'Results'/f'{name}_{i}'
   body.append(f'TABLE F{i} AS FREQUENCY OF {v["variable_id"]}\n OUTPUTFILE HTML "{stem}.html" UTF8')
   extra.append(str(stem)+f'_F{i}.html')
  body+=['DEFINE MUNIC.NUP AS COUNT UPA TYPE INTEGER',f'TABLE ENDLIST AS AREALIST OF MUNIC, MUNIC.NUP\n OUTPUTFILE CSV "{E / "Results" / (name+".csv")}" UTF8']
  p=program(name,'\n'.join(body));save(E/'Plans'/f'{name}.json',dict(name=name,program_sha256=sha(p),timeout_seconds=1800,outputs=[dict(path=str(E/'Results'/f'{name}.csv'),rows=339,columns=2)],extra_files=extra,fields=[v['variable_id'] for v in part]))
  shutil.copy2(p,D/'Programs'/p.name);queue.append(name)
 save(E/'discovery_queue.json',queue);print(len(queue),'national discovery batches',len(targets),'fields')
if __name__=='__main__':run()
